﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FSE
{
    public partial class Form3 : Form
    {
        public Form1.product loadedProduct;
        public List<Form1.featureProperty> availableProperties;
        public List<Form1.feature> listOfAvailableFeatures=new List<Form1.feature>();
        public Form3(List<Form1.featureProperty> availablePropertiesFromForm1,List<string> listOfCategoriesFromForm1, Form1.product loadedProductFromForm1,List<Form1.feature> availableFeatures)
        {
            InitializeComponent();
            listOfAvailableFeatures = availableFeatures;
            availableProperties = availablePropertiesFromForm1;
            loadedProduct = loadedProductFromForm1;
            comboBox2.DisplayMember = "Text";
            comboBox2.ValueMember = "Value";
            Form1.ComboboxItem item1 = new Form1.ComboboxItem();
            item1.Text = "Global";
            item1.Value = "Global";
            comboBox2.Items.Add(item1);
            foreach (string c in listOfCategoriesFromForm1)
            {
                Form1.ComboboxItem item = new Form1.ComboboxItem();

                item.Text = c;
                item.Value = c;
                comboBox2.Items.Add(item);
            }
            comboBox2.SelectedIndex = 0;
            listOfObjectives = Form1.listOfObjectives;


            comboBox3.DisplayMember = "Text";
            comboBox3.ValueMember = "Value";
            comboBox3.SelectedIndex = 0;
            comboBox7.DisplayMember = "Text";
            comboBox7.ValueMember = "Value";
            comboBox7.SelectedIndex = 0;
            foreach (Form1.featureProperty fp in availableProperties)
            {
                Form1.ComboboxItem item = new Form1.ComboboxItem();

                item.Text = fp.propertyName;
                item.Value = fp.propertyValue;
                comboBox3.Items.Add(item);
                if (isPropertyNumeric(fp.propertyName)) {
                    comboBox7.Items.Add(item);
                }
            }
            comboBox1.SelectedIndex = 0;
            comboBox8.SelectedIndex = 0;

        }
        
        public List<categoryConstrain> listOfObjectives = new List<categoryConstrain>();
        public class categoryPropertyConstrain
        {
            public string propertyName;
            public int type;
            public decimal num1;
            public decimal num2;
        }
        public class categoryConstrain
        {
            public string categoryName; // global is also treated as a category with the name global
            public int minNumberOfInstancesOfThisCategory;
            public int maxNumberOfInstancesOfThisCategory;
            public int importance;
            public List<objectives> listOfFeaturePropertiesObjectives = new List<objectives>();
            public List<categoryPropertyConstrain> listOfCategoryPropertiesObjectives = new List<categoryPropertyConstrain>();
            public int multipleInstancesOfTheSameFeature;
            public bool favourFeaturesExistInOtherProducts;  //Priority to features that exist in other products of the SPL
            public objectives GetObjective(string propertyName)
            {
                foreach (objectives o in listOfFeaturePropertiesObjectives)
                {
                    if (o.propertyName.Equals(propertyName))
                    {
                        return o;
                    }
                }
                return null;
            }

        }
        public class objectives
        {
            public string propertyName;
            public int type;
            public decimal numeric1;
            public decimal numeric2;
            public string txt1;
            public string txt2;
            public int importance;
           
            
        }

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox3.SelectedIndex = 0;

            if (comboBox8.SelectedIndex == 1) {
                if (comboBox2.SelectedIndex > 0) {
                    checkBox2.Visible = false;
                    numericUpDown7.Visible = true;
                    label11.Visible = true;
                }
                else
                {
                    checkBox2.Visible = true;
                    numericUpDown7.Visible = false;
                    label11.Visible = false;
                }
            } else
            {
                checkBox2.Visible = false;
                numericUpDown7.Visible = false;
                label11.Visible = false;
            }

           


            if (comboBox2.SelectedIndex >0)
            {
                if (comboBox8.SelectedIndex == 2) {
                    label7.Visible = true;
                }
                else
                {
                    label7.Visible = false;
                }



                comboBox3.SelectedIndex = 0;
                if (comboBox8.SelectedIndex == 1)
                {
                    label1.Visible = true;
                    label2.Visible = true;
                    numericUpDown1.Visible = true;
                    numericUpDown2.Visible = true;
                    label5.Visible = true;
                    comboBox5.Visible = true;
                    button1.Visible = true;

                }
                else
                {
                    label1.Visible = false;
                    label2.Visible = false;
                    numericUpDown1.Visible = false;
                    numericUpDown2.Visible = false;
                    label5.Visible = false;
                    comboBox5.Visible = false;
                }
              
                numericUpDown1.Value = -1;
                numericUpDown2.Value = -1;
                comboBox5.SelectedIndex = 2;
               checkBox2.Checked = false;
                numericUpDown7.Value = 1;
                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals(comboBox2.Text))
                    {
                        numericUpDown1.Value = cc.minNumberOfInstancesOfThisCategory;
                        numericUpDown2.Value = cc.maxNumberOfInstancesOfThisCategory;
                        comboBox5.SelectedIndex = cc.importance;
                        numericUpDown7.Value = cc.multipleInstancesOfTheSameFeature;
                        //numericUpDown7.Visible = true;
                        //label11.Visible = true;
                        //checkBox2.Checked = cc.favourFeaturesExistInOtherProducts;
                       // checkBox2.Visible = false;
                    }
                }


            }
            else
            {
                numericUpDown1.Value = -1;
                numericUpDown2.Value = -1;
                comboBox5.SelectedIndex = 2;
                numericUpDown7.Value = 1;
                checkBox2.Checked = false;
                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals("Global"))
                    {
                        numericUpDown1.Value = cc.minNumberOfInstancesOfThisCategory;
                        numericUpDown2.Value = cc.maxNumberOfInstancesOfThisCategory;
                        comboBox5.SelectedIndex = cc.importance;
                        //numericUpDown7.Visible = false;
                       // label11.Visible = false;
                        checkBox2.Checked = cc.favourFeaturesExistInOtherProducts;
                        //checkBox2.Visible = true;
                    }
                }
                if (comboBox8.SelectedIndex == 1)
                {
                    label1.Visible = true;
                    label2.Visible = true;
                    numericUpDown1.Visible = true;
                    numericUpDown2.Visible = true;
                }
                else
                {
                    label1.Visible = false;
                    label2.Visible = false;
                    numericUpDown1.Visible = false;
                    numericUpDown2.Visible = false;
                }
                    label7.Visible = false;
                
                label5.Visible = false;
                comboBox5.Visible = false;
                
              
            }
            comboBox7.SelectedIndex = 0;
        }
       
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox4.SelectedIndex = 0;
            numericUpDown3.Value = 0;
            numericUpDown4.Value = 0;
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox6.SelectedIndex = 0;
            if (comboBox3.SelectedIndex >0)
            {
                comboBox4.Visible = true;
                button1.Visible = true;
                button3.Visible = true;
                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals(comboBox2.Text))
                    {
                        foreach (objectives o in cc.listOfFeaturePropertiesObjectives)
                        {
                            if (o.propertyName.Equals(comboBox3.Text))
                            {
                                comboBox4.SelectedIndex = o.type;
                                numericUpDown3.Value = o.numeric1;
                                numericUpDown4.Value = o.numeric2;
                                textBox1.Text = o.txt1;
                                textBox2.Text = o.txt2;
                                comboBox6.SelectedIndex = o.importance;

                            }
                        }
                    }
                }
                
            }
            else
            {
                comboBox4.Visible = false;
                label3.Visible = false;
                textBox1.Visible = false;
                numericUpDown3.Visible = false;
                numericUpDown4.Visible = false;
                textBox2.Visible = false;
                label4.Visible = false;
                label6.Visible = false;
                comboBox6.Visible = false;
                if (comboBox3.SelectedIndex == 0)
                {
                    button1.Visible = false;
                }
                else
                {
                    button1.Visible = true;
                }

            }
        }
        private bool isNumeric(string input)
        {
            input = input.Trim();
            for (int i = 0; i < input.Length ; i++)
            {
                if (!(input[i] == '.' || input[i] == '0' || input[i] == '1' || input[i] == '2' || input[i] == '3' || input[i] == '4' || input[i] == '5' || input[i] == '6' || input[i] == '7' || input[i] == '8' || input[i] == '9')) { return false; }
            }

            return true;
        }

        public bool isPropertyNumeric(string propertyName)
        {
            foreach (Form1.feature f in listOfAvailableFeatures)
            {
                if (!isNumeric(f.getPropertyValue(propertyName)))
                {
                    return false;
                }
            }

            return true;
        }
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            // first check for validity
            if (comboBox4.SelectedIndex>8)
            {
                if (!isPropertyNumeric(comboBox3.Text)) { MessageBox.Show("Warning! One or more features contains non-numeric data for the propery "+comboBox3.Text); }
            }


            if (comboBox4.SelectedIndex==1|| comboBox4.SelectedIndex == 2||comboBox4.SelectedIndex == 4|| comboBox4.SelectedIndex == 5)
            {
                label3.Visible = true;
                label3.Text = "Use + to seperate words";
                textBox1.Visible = true;
                label4.Visible = false;
                textBox2.Visible = false;
                numericUpDown3.Visible = false;
                numericUpDown4.Visible = false;
                label6.Visible = true;
                comboBox6.Visible = true;

            }
           
            else if (comboBox4.SelectedIndex==3||comboBox4.SelectedIndex==6||comboBox4.SelectedIndex==7 || comboBox4.SelectedIndex == 8)
            {
                label3.Visible = true;
                label3.Text = "Include:";
                label4.Text = "Exclude:";
                textBox1.Visible = true;
                label4.Visible = true;
                textBox2.Visible = true;
                numericUpDown3.Visible = false;
                numericUpDown4.Visible = false;
                label6.Visible = true;
                comboBox6.Visible = true;
            }
            
            else if (comboBox4.SelectedIndex == 9|| comboBox4.SelectedIndex == 10 || comboBox4.SelectedIndex == 11 || comboBox4.SelectedIndex == 12 || comboBox4.SelectedIndex == 13 || comboBox4.SelectedIndex == 14 || comboBox4.SelectedIndex == 15 || comboBox4.SelectedIndex == 19 || comboBox4.SelectedIndex == 20)
            {
                label3.Visible = false;
                textBox1.Visible = false;
                numericUpDown3.Visible = true;
                numericUpDown4.Visible = false;
                textBox2.Visible = false;
                label4.Visible = false;
                label6.Visible = true;
                comboBox6.Visible = true;
            }
          
            else if ((comboBox4.SelectedIndex == 16)||(comboBox4.SelectedIndex == 17) ||(comboBox4.SelectedIndex == 18))
            {
                label3.Visible = true;
                textBox1.Visible = false;
                numericUpDown3.Visible = true;
                numericUpDown4.Visible = true;
                textBox2.Visible = false;
                label4.Visible = true;
                label3.Text = "From:";
                label4.Text = "To:";
                label6.Visible = true;
                comboBox6.Visible = true;
            }
            else
            {
                label3.Visible = false;
                textBox1.Visible = false;
                numericUpDown3.Visible = false;
                numericUpDown4.Visible = false;
                textBox2.Visible = false;
                label4.Visible = false;
                label6.Visible = false;
                comboBox6.Visible = false;

            }
        }
        public string displayAllObjectives(List<Form3.categoryConstrain> ListOfCC)
        {
            string output = "";
            foreach (Form3.categoryConstrain cc in ListOfCC)
            {

                output = output + Environment.NewLine + Environment.NewLine + cc.categoryName;

              //  if (cc.categoryName.Equals("Global"))
               // {
                    output = output + Environment.NewLine + "Multiple instances of the same feature:" + cc.multipleInstancesOfTheSameFeature.ToString() + Environment.NewLine + "Favour features that exist in other products of the SPL:" + cc.favourFeaturesExistInOtherProducts.ToString();

             //   }
                output = output + Environment.NewLine + "Min number of features:" + cc.minNumberOfInstancesOfThisCategory + " Max number of features:" + cc.maxNumberOfInstancesOfThisCategory ;
                if (!cc.categoryName.Equals("Global"))
                {
                    output = output + "Importance:" + cc.importance.ToString();
                }
                output = output + Environment.NewLine + "Category Property Constraints:";
                foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                {



                    if (cpc.type == 1)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " less than ";
                    }
                    else if (cpc.type == 2)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " more than ";
                    }
                    else if (cpc.type == 3)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " between " + cpc.num2 + " and ";
                    }

                    output = output + cpc.num1;


                }
                output = output + Environment.NewLine + "Feature Property Constraints:";
                foreach (Form3.objectives o in cc.listOfFeaturePropertiesObjectives)
                {
                    output = output + Environment.NewLine + o.propertyName + " ";
                    if (o.type == 1)
                    {
                        output = output + "Include:" + o.txt1 + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 2)
                    {
                        output = output + "Exclude:" + o.txt1 + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 3)
                    {
                        output = output + "Include:" + o.txt1 + "AND Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 4)
                    {
                        output = output + "Must Include:" + o.txt1 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 5)
                    {
                        output = output + "Must Exclude:" + o.txt1 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 6)
                    {
                        output = output + "Must Include:" + o.txt1 + "AND Must Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 7)
                    {
                        output = output + "Must Include:" + o.txt1 + "AND Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 8)
                    {
                        output = output + "Include:" + o.txt1 + "AND Must Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                   


                    else if (o.type == 9)
                    {
                        output = output + "Equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 10)
                    {
                        output = output + "Approximately equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 11)
                    {
                        output = output + "Not equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 12)
                    {
                        output = output + "upto (Higher better):" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 13)
                    {
                        output = output + "upto (Lower better):" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 15)
                    {
                        output = output + "Less than:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 14)
                    {
                        output = output + "More than:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 16)
                    {
                        output = output + "Between " + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 17)
                    {
                        output = output + "Between (Higher better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 18)
                    {
                        output = output + "Between (Lower better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 19)
                    {
                        output = output + "Above (Higher better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 20)
                    {
                        output = output + "Above (Lower better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }


                }

            }
            return output;

        }

        private void button2_Click(object sender, EventArgs e)
        {
          //  MessageBox.Show(comboBox3.Text);
           MessageBox.Show(displayAllObjectives(listOfObjectives));
        }
        private void addNewObjective(bool c)
        {
            
            // if c==true then add new category else add objective under an existing cateogry
            if (c)
            {
                categoryConstrain tmpCategoryConstrain = new categoryConstrain();
                tmpCategoryConstrain.categoryName = comboBox2.Text;
                tmpCategoryConstrain.importance= comboBox5.SelectedIndex;
                tmpCategoryConstrain.maxNumberOfInstancesOfThisCategory = (int)numericUpDown2.Value;
                tmpCategoryConstrain.minNumberOfInstancesOfThisCategory = (int)numericUpDown1.Value;
                tmpCategoryConstrain.multipleInstancesOfTheSameFeature = (int)numericUpDown7.Value;
                tmpCategoryConstrain.favourFeaturesExistInOtherProducts = checkBox2.Checked;

                // if category Property constrain
                if (comboBox7.SelectedIndex > 0)
                {
                    if (comboBox1.SelectedIndex>0)
                    {
                        categoryPropertyConstrain cpc = new categoryPropertyConstrain();
                        cpc.propertyName = comboBox7.Text;
                        cpc.type = comboBox1.SelectedIndex;
                        cpc.num1 = (int)numericUpDown5.Value;
                        cpc.num2 = (int)numericUpDown6.Value;
                        tmpCategoryConstrain.listOfCategoryPropertiesObjectives.Add(cpc);
                    }

                }


                // if there also property objectives, then add them
                if (comboBox3.SelectedIndex > 0)
                {
                    if (comboBox4.SelectedIndex > 0)
                    {
                        objectives tmpObjective = new objectives();

                        tmpObjective.propertyName = comboBox3.Text;
                        tmpObjective.importance = comboBox6.SelectedIndex;
                        tmpObjective.numeric1 = (int)numericUpDown3.Value;
                        tmpObjective.numeric2 = (int)numericUpDown4.Value;
                        tmpObjective.txt1 = textBox1.Text;
                        tmpObjective.txt1 = textBox2.Text;
                        tmpObjective.type = comboBox4.SelectedIndex;


                        tmpCategoryConstrain.listOfFeaturePropertiesObjectives.Add(tmpObjective);
                    }
                }
                listOfObjectives.Add(tmpCategoryConstrain);
                MessageBox.Show("New category level objective and/or objective under new category added");
                button1.PerformClick();
                
            }
            else
            {
                //add objective under selected category
                foreach (categoryConstrain tcc in listOfObjectives)
                {
                   
                    if (tcc.categoryName.Equals(comboBox2.Text))
                    {

                        // if category Property constrain
                        if (comboBox7.SelectedIndex > 0)
                        {
                            if (comboBox1.SelectedIndex > 0)
                            {
                                foreach (categoryPropertyConstrain pc in tcc.listOfCategoryPropertiesObjectives)
                                {
                                    if (pc.propertyName.Equals(comboBox7.Text))
                                    {
                                        pc.type = comboBox1.SelectedIndex;
                                        pc.num1 = (int)numericUpDown5.Value;
                                        pc.num2 = (int)numericUpDown6.Value;
                                    }
                                }
                               
                             
                            }

                        }

                        if (comboBox4.SelectedIndex > 0)
                        {
                            objectives o = new objectives();
                            // update category objective
                            tcc.importance = comboBox5.SelectedIndex;
                            tcc.maxNumberOfInstancesOfThisCategory = (int)numericUpDown2.Value;
                            tcc.minNumberOfInstancesOfThisCategory = (int)numericUpDown1.Value;
                            tcc.multipleInstancesOfTheSameFeature = (int)numericUpDown7.Value;
                            tcc.favourFeaturesExistInOtherProducts = checkBox2.Checked;
                            // update property objectives
                            o.propertyName = comboBox3.Text;
                            o.importance = comboBox6.SelectedIndex;
                            o.numeric1 = (int)numericUpDown3.Value;
                            o.numeric2 = (int)numericUpDown4.Value;
                            o.txt1 = textBox1.Text;
                            o.txt2 = textBox2.Text;
                            o.type = comboBox4.SelectedIndex;
                            tcc.listOfFeaturePropertiesObjectives.Add(o);
                            MessageBox.Show("New objective added under category " + comboBox2.Text);
                        }
                            return;
                            
                        
                    }
                }
               
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (((int)numericUpDown1.Value > (int)numericUpDown2.Value) && ((int)numericUpDown2.Value!=-1))
            {
                MessageBox.Show("The Max number of features can not be less than the Min number of features");

            }
            else
            {
                // first check if it is updating an existing objective or setting a new one. 
                bool newCC = true;
                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals(comboBox2.Text))
                    {
                        newCC = false;
                        // check if category level objective only
                        if (comboBox8.SelectedIndex == 1)
                        {

                            // update category objective
                            cc.importance = comboBox5.SelectedIndex;
                            cc.maxNumberOfInstancesOfThisCategory = (int)numericUpDown2.Value;
                            cc.minNumberOfInstancesOfThisCategory = (int)numericUpDown1.Value;
                            cc.multipleInstancesOfTheSameFeature = (int)numericUpDown7.Value;
                            cc.favourFeaturesExistInOtherProducts = checkBox2.Checked;
                            MessageBox.Show("Category level constraints updated");

                            if (comboBox7.SelectedIndex > 0)
                            {
                                int abc = 0;
                                int propertyIndex = -1;
                                foreach (categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                                {// if u find a property under the same cateogry with the same name that update it and exit
                                    if (cpc.propertyName.Equals(comboBox7.Text))
                                    {// update category objective


                                        cpc.propertyName = comboBox7.Text;
                                        cpc.type = comboBox1.SelectedIndex;
                                        cpc.num1 = (int)numericUpDown5.Value;
                                        cpc.num2 = (int)numericUpDown6.Value;
                                        propertyIndex = abc;

                                    }
                                    abc++;

                                }
                                if (propertyIndex == -1)
                                {
                                    if (comboBox1.SelectedIndex > 0)
                                    {
                                        categoryPropertyConstrain cpc = new categoryPropertyConstrain();
                                        cpc.propertyName = comboBox7.Text;
                                        cpc.type = comboBox1.SelectedIndex;
                                        cpc.num1 = (int)numericUpDown5.Value;
                                        cpc.num2 = (int)numericUpDown6.Value;
                                        cc.listOfCategoryPropertiesObjectives.Add(cpc);
                                    }
                                }
                                else
                                {
                                    // if found but is now set to null it should be deleted
                                    if (comboBox1.SelectedIndex == 0)
                                    {
                                        cc.listOfCategoryPropertiesObjectives.RemoveAt(propertyIndex);
                                        MessageBox.Show("Category Property Objective removed");
                                    }

                                }
                            }



                            return;
                        }
                        else
                        {
                            int iii = 0;
                            foreach (objectives o in cc.listOfFeaturePropertiesObjectives)
                            {// if u find a property under the same cateogry with the same name that update it and exit
                                if (o.propertyName.Equals(comboBox3.Text))
                                {
                                    // update category objective
                                    cc.importance = comboBox5.SelectedIndex;
                                    cc.maxNumberOfInstancesOfThisCategory = (int)numericUpDown2.Value;
                                    cc.minNumberOfInstancesOfThisCategory = (int)numericUpDown1.Value;
                                    cc.multipleInstancesOfTheSameFeature = (int)numericUpDown7.Value;
                                    cc.favourFeaturesExistInOtherProducts = checkBox2.Checked;
                                    // update property objectives
                                    o.importance = comboBox6.SelectedIndex;
                                    o.numeric1 = (int)numericUpDown3.Value;
                                    o.numeric2 = (int)numericUpDown4.Value;
                                    o.txt1 = textBox1.Text;
                                    o.txt2 = textBox2.Text;

                                    o.type = comboBox4.SelectedIndex;
                                    if (comboBox4.SelectedIndex == 0) // if null then this objective should be removed
                                    {
                                        cc.listOfFeaturePropertiesObjectives.RemoveAt(iii);
                                        MessageBox.Show("Feature Property Objective removed");
                                        return;
                                    }


                                    MessageBox.Show("Objectives updated");
                                    return;
                                }
                                iii++;

                            }


                            addNewObjective(false);
                            return;

                        }

                    }



                }
                addNewObjective(newCC);  
                Form1.listOfObjectives = listOfObjectives;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            this.Close();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox7.SelectedIndex>0)
            {
                comboBox1.Visible = true;
                comboBox1.SelectedIndex = 0;
               

                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals(comboBox2.Text))
                    {
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            if (cpc.propertyName.Equals(comboBox7.Text))
                            {
                                comboBox1.SelectedIndex = cpc.type;
                                numericUpDown5.Value = cpc.num1;
                                numericUpDown5.Visible = true;
                                if (comboBox1.SelectedIndex > 4)
                                {
                                    numericUpDown6.Value = cpc.num2;
                                    numericUpDown6.Visible = true;
                                }
                                else
                                {
                                    numericUpDown6.Visible = false;
                                }

                            }
                        }
                    }
                }
                    



                }
            else
            {
                comboBox1.Visible = false;
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                label10.Visible = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1|| comboBox1.SelectedIndex == 2)
            {
                numericUpDown5.Visible = true;
                numericUpDown6.Visible = false;
                label10.Visible = false;
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                numericUpDown5.Visible = true;
                numericUpDown6.Visible = true;
                label10.Visible = true;
            }
            else
            {
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                label10.Visible = false;
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox8.SelectedIndex == 1)// product/category level objectives
            {
                comboBox2.Visible = true;
                
                comboBox3.Visible = false;
                comboBox4.Visible = false;
                comboBox5.Visible = false;
                comboBox6.Visible = false;
                comboBox7.Visible = true;
                comboBox1.Visible = false;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
                label8.Visible = false;
                label9.Visible = true;
                label10.Visible = false;
                numericUpDown7.Visible = false;
                label11.Visible = false;
                checkBox2.Visible = true;
                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                numericUpDown3.Visible = false;
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                numericUpDown4.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                button1.Visible = true;
                comboBox2.SelectedIndex = 0;
                numericUpDown1.Value = -1;
                numericUpDown2.Value = -1;
                comboBox5.SelectedIndex = 2;
                numericUpDown7.Value = 1;
                checkBox2.Checked = false;
                foreach (categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals("Global"))
                    {
                        numericUpDown1.Value = cc.minNumberOfInstancesOfThisCategory;
                        numericUpDown2.Value = cc.maxNumberOfInstancesOfThisCategory;
                        comboBox5.SelectedIndex = cc.importance;
                        numericUpDown7.Value = cc.multipleInstancesOfTheSameFeature;
                        checkBox2.Checked = cc.favourFeaturesExistInOtherProducts;
                    }
                }
            }
            else if (comboBox8.SelectedIndex == 2) // feature level objectives
            {
              
                comboBox4.Visible = false;
                comboBox5.Visible = false;
                comboBox6.Visible = false;
                comboBox7.Visible = false;
                comboBox1.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
                label8.Visible = true;
                label9.Visible = false;
                label10.Visible = false;
                numericUpDown7.Visible = false;
                label11.Visible = false;
                checkBox2.Visible = false;
                numericUpDown1.Visible = false;
                numericUpDown2.Visible = false;
                numericUpDown3.Visible = false;
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                numericUpDown4.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                button1.Visible = false;
                comboBox2.Visible = true;
                comboBox2.SelectedIndex = 0;
                comboBox3.Visible = true;
                comboBox3.SelectedIndex = 0;
            }
            else
            {
                comboBox2.Visible = false;
                comboBox3.Visible = false;
                comboBox4.Visible = false;
                comboBox5.Visible = false;
                comboBox6.Visible = false;
                comboBox7.Visible = false;
                comboBox1.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = false;
                label8.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
                numericUpDown7.Visible = false;
                label11.Visible = false;
                checkBox2.Visible = false;
                numericUpDown1.Visible = false;
                numericUpDown2.Visible = false;
                numericUpDown3.Visible = false;
                numericUpDown5.Visible = false;
                numericUpDown6.Visible = false;
                numericUpDown4.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                button1.Visible = false;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex > 0)
            {
                numericUpDown5.Visible = true;
                if (comboBox1.SelectedIndex > 2)
                {
                    label10.Visible = true;
                    numericUpDown6.Visible = true;
                }
                else
                {
                    label10.Visible = false;
                    numericUpDown6.Visible = false;
                }
            }
            else
            {
                label10.Visible = false;
                numericUpDown6.Visible = false;
                numericUpDown5.Visible = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
