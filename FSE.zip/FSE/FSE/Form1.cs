﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Header;

namespace FSE
{
    public partial class Form1 : Form
    {
        public class quantifiedProperty
        {
            public string propertyName;
            public decimal value;

        }
        public feature getAvailableFeature(string featureName)
        {
            foreach (feature f in listOfAvailableFeatures)
            {
                if (f.featureName.Equals(featureName)) { return f; }
            }
            return null;
        }
        public class quantifiedFeature
        {
            public decimal AddedValuePerCostUnit;
            public string featureName;
            public string category;
            public int occurenciesOfFeatureExistInOtherProductsOfTheSPL;
          
            public quantifiedFeature(string name,string cat)
            {
                featureName = name;
                category = cat;
                addedValue = 0m;
            }
            public void addQuantifiedProperty(quantifiedProperty qpINPUT)
            {
                // if the property exist, overwrite it. Else add a new one to the list
                foreach (quantifiedProperty qp in listOfQuantifiedProperties)
                {
                    if (qp.propertyName.Equals(qpINPUT.propertyName)) { qp.value = qpINPUT.value; return; }
                    
                }
                listOfQuantifiedProperties.Add(qpINPUT);
            }

            public List<quantifiedProperty> listOfQuantifiedProperties = new List<quantifiedProperty>();
            public decimal getQuantifiedPropertyValue(string pName)
            {
                foreach (quantifiedProperty qp in listOfQuantifiedProperties)
                {
                    if (qp.propertyName.Equals(pName))
                    {
                        return qp.value;
                    }
                }
                return -2m;
            }

            public decimal addedValue;
            public Form3.objectives getObjectiveObject(string propertyName, string category)
            {
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    //   MessageBox.Show(cc.categoryName+" "+category);

                    if (cc.categoryName.Equals(category))
                    {

                        if ((cc.GetObjective(propertyName) != null)&&(cc.GetObjective(propertyName).propertyName.Equals(propertyName)))
                        {
                            return cc.GetObjective(propertyName);
                        }

                    }
                   

                }
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals("Global"))
                    {
                        if ((cc.GetObjective(propertyName) != null) && (cc.GetObjective(propertyName).propertyName.Equals(propertyName)))
                        {
                            return cc.GetObjective(propertyName);
                        }
                    }
                }

                    return null;
            }
            public void setAddedValue()
            {
                addedValue = 0m;
                foreach (quantifiedProperty qp in listOfQuantifiedProperties)
                {
                    // if property is violating an objective set the value to 0
                    Form3.objectives t = getObjectiveObject(qp.propertyName, category);
                    if (t != null)
                    {
                        
                        if ((t.importance == 4) && (qp.value <= 0))
                        {
                            addedValue = 0m;
                            return;
                        }
                        else
                        {
                            // calculate addedvalue
                            decimal propertyImportanceMultiplier = 0.0m;
                            if (t.importance == 0) { propertyImportanceMultiplier = 0.25m; }
                            else if (t.importance == 1) { propertyImportanceMultiplier = 0.5m; }
                            else if (t.importance == 2) { propertyImportanceMultiplier = 0.75m; }
                            else if (t.importance >  2) { propertyImportanceMultiplier = 1m; }
                            
                            addedValue = addedValue + (qp.value * propertyImportanceMultiplier);

                        }

                    }
                }
                // find the global and cat objectives.
                Form3.categoryConstrain cc=null;// category constrains
                Form3.categoryConstrain gc=null;// global constrains
                foreach (Form3.categoryConstrain c in listOfObjectives)
                {
                    if (c.categoryName.Equals("Global"))
                    {
                        gc = c;
                    }
                    if (c.categoryName.Equals(category))
                    {
                        cc = c;
                    }

                }

                // check if the feature should get a bonus in case it exist in another product of the SPL
                if (gc != null)
                {
                    if (gc.favourFeaturesExistInOtherProducts && (occurenciesOfFeatureExistInOtherProductsOfTheSPL > 0))
                    {
                        addedValue = addedValue + 0.1m;
                    }
                }

                // multiply the feature added value by the category importance 
                decimal m = 0m;
                if (cc != null)
                {
                    if (cc.importance < 1) { m = 0.01m; } // not important
                    else if (cc.importance == 1) { m = 0.25m; } // low
                    else if (cc.importance == 2) { m = 0.5m; } // medium
                    else if (cc.importance == 3) { m = 0.75m; } // high
                    else if (cc.importance > 3) { m = 1m; } // very high
                }
                else
                {
                    m = 0.5m;// defult value in case of no objective
                }
                addedValue = addedValue * m;
                                             
            }
        }
     
        public bool isNumeric(string input)
        {
            input = input.Trim();
            for (int i = 0;i< input.Length; i++){
                if (!(input[i] == '.' || input[i]=='0'||input[i]=='1' || input[i] == '2' || input[i] == '3' || input[i] == '4' || input[i] == '5' || input[i] == '6' || input[i] == '7' || input[i] == '8' || input[i] == '9')) { return false; }
            }

            return true;
        }

        public bool isPropertyNumeric(string propertyName,List<feature> lf)
        {
            foreach (feature f in lf)
            {
                if (!isNumeric(f.getPropertyValue(propertyName)))
                {
                    return false;
                }
            }

            return true;
        }

        public List<quantifiedFeature> listOfAvailableQuantifiedFeatures = new List<quantifiedFeature>();
        public List<feature> listOfAvailableFeatures = new List<feature>();
        public List<string> listOfAvailableCategories = new List<string>();
        public class featureProperty
        {
           public string propertyName = "";
           public  string propertyValue = "";
          public  featureProperty(string name,string value) { propertyName = name; propertyValue = value; }

        }
       
        public class feature
        {
            public bool isNumeric(string input)
            {
                input = input.Trim();
                for (int i = 0; i < input.Length; i++)
                {
                    if (!(input[i] == '.' || input[i] == '0' || input[i] == '1' || input[i] == '2' || input[i] == '3' || input[i] == '4' || input[i] == '5' || input[i] == '6' || input[i] == '7' || input[i] == '8' || input[i] == '9')) { return false; }
                }

                return true;
            }
            public feature(string name,string cat) { featureName = name; category = cat; }
            public string featureName = "";
            public string category = "";
            public List<featureProperty> ListOfProperties=new List<featureProperty>();

            public List<featureProperty> listAvailableProperties()
            {
               
        return ListOfProperties;
            }


            public string getPropertyValue(string name)
            {
                foreach (featureProperty fp in ListOfProperties)
                {
                    if (fp.propertyName.Equals(name)) return fp.propertyValue;
                }
                return "";

            }
            public Decimal getNumericPropertyValue(string name)
            {
                string value = "";
                foreach (featureProperty fp in ListOfProperties)
                {
                    if (fp.propertyName.Equals(name)) {
                        value = fp.propertyValue;
                        if ((value.Length < 1) || (!isNumeric(value)))
                        {
                            return 0m;
                        }
                        else
                        {
                            return Decimal.Parse(value);
                        }
                    }
                }
                
                return 0m;


            }
            public void EditPropertyValue(string name,string value)
            {
                foreach (featureProperty fp in ListOfProperties)
                {
                    if (fp.propertyName.Equals(name)) fp.propertyValue=value;
                }
                

            }
            public void EditPropertyName(string name, string newName)
            {
                foreach (featureProperty fp in ListOfProperties)
                {
                    if (fp.propertyName.Equals(name)) fp.propertyName = newName;
                }
            } 
            public void addProperty(string name, string value)
            {
                ListOfProperties.Add(new featureProperty(name,value));

            }
            public void removeProperty(string name)
            {
                int index = 0;
                foreach (featureProperty fp in ListOfProperties)
                {
                    if (fp.propertyName.Equals(name))
                    {
                        ListOfProperties.RemoveAt(index);
                        return;
                    }
                    index++;
                }

            }

        }
        
        public static List<Form3.categoryConstrain> listOfObjectives = new List<Form3.categoryConstrain>();
        public List<quantifiedFeature> listOfSortedByAddedValueQuantifiedFeatures = new List<quantifiedFeature>();
        public List<quantifiedFeature> sortAvailableQuantifiedFeaturesByCostDividedByAddedValue(List<quantifiedFeature> listOfAvailableQuantifiedFeatures)
        {
            List<quantifiedFeature> tmpListOfQuantifiedFeatures = new List<quantifiedFeature>();
            List<quantifiedFeature> listOfSortedQuantifiedFeatures = new List<quantifiedFeature>();
            foreach (quantifiedFeature q in listOfAvailableQuantifiedFeatures)
            {
                tmpListOfQuantifiedFeatures.Add(q);
            }

            while (listOfSortedQuantifiedFeatures.Count() < listOfAvailableQuantifiedFeatures.Count())
            {
                decimal tempMaxAddedValue = -2m;
                int tempMaxFeatureIndex = 0;
                int currentFeatureIndex = 0;
                foreach (quantifiedFeature qf in tmpListOfQuantifiedFeatures)
                {
                    if (qf.AddedValuePerCostUnit > tempMaxAddedValue)
                    {
                        tempMaxAddedValue = qf.AddedValuePerCostUnit;
                        tempMaxFeatureIndex = currentFeatureIndex;
                    }

                    currentFeatureIndex++;

                }
                listOfSortedQuantifiedFeatures.Add(tmpListOfQuantifiedFeatures.ElementAt(tempMaxFeatureIndex));
                tmpListOfQuantifiedFeatures.RemoveAt(tempMaxFeatureIndex);
            }
            return listOfSortedQuantifiedFeatures;
        }


        public void sortAvailableQuantifiedFeaturesByAddedValue()
        {
            List<quantifiedFeature> tmpListOfQuantifiedFeatures = new List<quantifiedFeature>();
             
            foreach (quantifiedFeature q in listOfAvailableQuantifiedFeatures)
            {
                tmpListOfQuantifiedFeatures.Add(q);
            }

            while (listOfSortedByAddedValueQuantifiedFeatures.Count()< listOfAvailableQuantifiedFeatures.Count()) {
                decimal tempMaxAddedValue = -2m;
                int tempMaxFeatureIndex = 0;
                int currentFeatureIndex = 0;
                foreach (quantifiedFeature qf in tmpListOfQuantifiedFeatures)
                {
                    if (qf.addedValue > tempMaxAddedValue)
                    {
                        tempMaxAddedValue = qf.addedValue;
                        tempMaxFeatureIndex = currentFeatureIndex;
                    }
                                  
                    currentFeatureIndex++;
                
                }
                listOfSortedByAddedValueQuantifiedFeatures.Add(tmpListOfQuantifiedFeatures.ElementAt(tempMaxFeatureIndex));
                tmpListOfQuantifiedFeatures.RemoveAt(tempMaxFeatureIndex);
            }
        }
        public int numberOfAvailableFeaturesUnderCategory(string categoryNameToBeChecked)
        {
            int t = 0;
            

                foreach (feature f in listOfAvailableFeatures)
                {
                    if (f.category.Equals(categoryNameToBeChecked))
                    {
                        t++;
                    }
                }
            
            
            return t;
        }
        public class product
        {
            public static void updateLoadedProductObjectives() { i=1; }
            public static int i = 0;
            public product(string n) { name = n;  }
            public string name;
            public string SPLName;
            public decimal getTotalValueForFeatureProperty(string propertyName,string category)
            {
                decimal v=0;
                //if (category.Equals("Global")) MessageBox.Show("G");
                foreach (feature f in ListOfFeatures)
                {
                    if (category.Equals("Global")||category.Equals(f.category)) {
                        v = v + f.getNumericPropertyValue(propertyName);
                    }
                }

                return v;
            }

            public int numberOfFeaturesUnderCategory(string categoryNameToBeChecked)
            {
                int t = 0;
                if (!categoryNameToBeChecked.Equals("Global")) {
              
                    foreach (feature f in ListOfFeatures)
                    {
                        if (f.category.Equals(categoryNameToBeChecked))
                        {
                            t++;
                        }
                    }
                }
                else
                {
                    t= ListOfFeatures.Count();
                }
                return t;
            }



            public void loadProductFeaturesFromFile()
            {
                
                string productFileName = "./" + name + ".xml";
                bool fileExists = (System.IO.File.Exists(@productFileName) ? true : false);
                if (fileExists)
                {
                    //load
                    XmlDataDocument xmldoc1 = new XmlDataDocument();
                    XmlNodeList xmlnode1;
                    System.IO.StreamReader file1 = new System.IO.StreamReader(@productFileName);
                    xmldoc1.Load(file1);
                    file1.Close();
                    xmlnode1 = xmldoc1.GetElementsByTagName("Feature");
                    for (int i = 0; i <= xmlnode1.Count - 1; i++)
                    {

                        feature tmpFeature = new feature(xmlnode1[i].ChildNodes.Item(0).InnerText.Trim(), xmlnode1[i].ChildNodes.Item(1).InnerText.Trim());
                        addFeature(tmpFeature);
                    }

                }
                
            }
            public int numberOfOccurenciesOfFeatureInProduct(string featureNameToCheck)
            {
                // get number of occurencies of the feature in the product 
                int t = 0;
                foreach (feature f in ListOfFeatures)
                {
                    if (f.featureName.Equals(featureNameToCheck))
                    {
                        t++;
                    }
                }
                return t;
            }

            public List<feature> returnListOfFeatures()
            {
                return ListOfFeatures;

            }
            public List<feature> ListOfFeatures = new List<feature>();
            public void addFeature(feature f) { ListOfFeatures.Add(f); }
            public feature getFeature(string name) {
                foreach (feature f in ListOfFeatures)
                {
                    if (f.featureName.Equals(name)) return f;
                }
                return null;
            }
            public void deleteAllFeatures()
            {
                ListOfFeatures.Clear();
            }
            public void deleteFeature(string name)
            {
                int index = 0;
                foreach (feature f in ListOfFeatures)
                {
                    if (f.featureName.Equals(name)) ListOfFeatures.RemoveAt(index);
                    index++;
                }
                
            }
        }
            public class ComboboxItem
        {
            public string Text { get; set; }
            public object Value { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        //public class objective
       // {
            

        //}

        public class SPL
        {
            public SPL(string n) { SPLName = n; }
            public string SPLName = "";
            public List<product> ListOfProducts = new List<product>();
            public void addProduct(product p) { ListOfProducts.Add(p); }
            public product getProduct(string nameP)
            {
                foreach (product p in ListOfProducts)
                {
                    if (p.name.Equals(nameP)) return p;
                }
                return null;
            }
            public product getProductByIndex(int index)
            {
                return ListOfProducts[index];
                
                 
            }
            public void deleteProduct(string comboxText)
            {
                int iii = 0;
                int deleteIndex = -1;
                foreach (product p in ListOfProducts)
                {
                    if (p.name.Equals(comboxText)) { deleteIndex = iii; }
                    iii++;
                }
                ListOfProducts.RemoveAt(deleteIndex);



            }


        }

        public List<SPL> ListOfSPLs = new List<SPL>();
        public bool fileExists;
        public product loadedProduct = new product("");
        public string filePath = @".\profile.xml";
        
        public void loadSPLs()
        {
            comboBox1.Items.Clear();
            ListOfSPLs.Clear();
            fileExists = (System.IO.File.Exists(filePath) ? true : false);
            if (fileExists)
            {
                XmlDataDocument xmldoc = new XmlDataDocument();
                XmlNodeList xmlnode;
                System.IO.StreamReader file = new System.IO.StreamReader(filePath);
                xmldoc.Load(file);
                file.Close();

                xmlnode = xmldoc.GetElementsByTagName("SPL");
                comboBox1.DisplayMember = "Text";
                comboBox1.ValueMember = "Value";

                for (int i = 0; i <= xmlnode.Count - 1; i++)
                {
                    ComboboxItem item = new ComboboxItem();
                    item.Text = xmlnode[i].ChildNodes.Item(0).InnerText.Trim();
                    item.Value = i;
                    SPL tempSPL = new SPL(item.Text);
                  
                 

                    for (int ii = 0; ii <= xmlnode[i].ChildNodes.Item(1).ChildNodes.Count - 1; ii++)
                  {
                       tempSPL.addProduct(new product(xmlnode[i].ChildNodes.Item(1).ChildNodes.Item(ii).InnerText.Trim()));
                  }
                    
   
                    ListOfSPLs.Add(tempSPL);
                    comboBox1.Items.Add(item);


                }


            }

        }
        public void loadProducts()
        {
            comboBox2.Items.Clear();
            comboBox2.DisplayMember = "Text";
            comboBox2.ValueMember = "Value";
            int index = 0;
            foreach (product p in ListOfSPLs[SPLComboboxIndex].ListOfProducts)
            {
                ComboboxItem item = new ComboboxItem();
                item.Text = p.name;
                item.Value = index;
                comboBox2.Items.Add(item);
                index++;
            }

        }
     
        public int SortByNameAscending(string name1, string name2)
        {

            return name1.CompareTo(name2);
        }
        public List<string> productCategories = new List<string>();
        public void displayProductFeatures(int i)
        {
            foreach (feature ff in loadedProduct.ListOfFeatures)
            {
                addProductCategory (ff.category);
           

            }
            
            treeView2.Nodes.Clear();
            if (i == 0)
            {
                int fid = 0;
                foreach (feature f in loadedProduct.ListOfFeatures)
                {
                    treeView2.Nodes.Add(f.featureName);
                    treeView2.Nodes[fid].Nodes.Add(f.category);
                    foreach (featureProperty p in f.ListOfProperties)
                    {
                        treeView2.Nodes[fid].Nodes.Add(p.propertyName + ":" + p.propertyValue);
                    }
                    fid++;
                }
            }
            if (i == 1)
            {
                int cid = 0;
                foreach (string s in productCategories)
                {
                    treeView2.Nodes.Add(s);
                    int fid = 0;
                    foreach (feature f in loadedProduct.ListOfFeatures)
                    {
                       if (f.category.Equals(s))
                        {
                            treeView2.Nodes[cid].Nodes.Add(f.featureName);
                            foreach (featureProperty p in f.ListOfProperties)
                            {
                                treeView2.Nodes[cid].Nodes[fid].Nodes.Add(p.propertyName + ":" + p.propertyValue);
                            }
                        fid++;
                    }
                        
                    }
                    cid++;
                }

            }
        }


 


    public void displayAvailableFeatures(int i)
        {
            

            treeView1.Nodes.Clear();
            if (i == 0)
            {
                int fid = 0;
                foreach (feature f in listOfAvailableFeatures)
                {
                    treeView1.Nodes.Add(f.featureName);
                    treeView1.Nodes[fid].Nodes.Add(f.category+" ("+ numberOfAvailableFeaturesUnderCategory(f.category) + ")");
                    foreach (featureProperty p in f.ListOfProperties)
                    {
                        treeView1.Nodes[fid].Nodes.Add(p.propertyName+":"+p.propertyValue);
                    }
                    fid++;
                }
            }
            if (i==1)
            {
                int cid = 0;
                foreach (string s in listOfAvailableCategories)
                {
                    treeView1.Nodes.Add(s+" ("+ numberOfAvailableFeaturesUnderCategory(s)+ ")");
                    int fid = 0;
                    foreach (feature f in listOfAvailableFeatures)
                    {
                        if (f.category.Equals(s))
                        {
                            treeView1.Nodes[cid].Nodes.Add(f.featureName);
                            foreach (featureProperty p in f.ListOfProperties)
                            {
                                treeView1.Nodes[cid].Nodes[fid].Nodes.Add(p.propertyName + ":" + p.propertyValue);
                            }
                            fid++;
                        }
                        
                    }
                    cid++;
                }

            }
        }
        public void displayQuantifiedFeatures(int i)
        {


            treeView3.Nodes.Clear();
            if (i == 0)
            {
                int fid = 0;
                foreach (quantifiedFeature f in listOfAvailableQuantifiedFeatures)
                {
                    treeView3.Nodes.Add(f.featureName);
                    treeView3.Nodes[fid].Nodes.Add("Category:"+f.category);
                    treeView3.Nodes[fid].Nodes.Add("AddedValue:"+f.addedValue.ToString());
                    treeView3.Nodes[fid].Nodes.Add("Occurencies in other products:" + f.occurenciesOfFeatureExistInOtherProductsOfTheSPL.ToString());
                    foreach (quantifiedProperty p in f.listOfQuantifiedProperties)
                    {
                        treeView3.Nodes[fid].Nodes.Add(p.propertyName + ":" + p.value+"%");
                    }
                    fid++;
                }
            }
            if (i == 2)
            {
                int fid = 0;
                foreach (quantifiedFeature f in listOfSortedByAddedValueQuantifiedFeatures)
                {
                    treeView3.Nodes.Add(f.featureName);
                    treeView3.Nodes[fid].Nodes.Add("Category:" + f.category);
                    treeView3.Nodes[fid].Nodes.Add("AddedValue:" + f.addedValue.ToString());
                    treeView3.Nodes[fid].Nodes.Add("Occurencies in other products:" + f.occurenciesOfFeatureExistInOtherProductsOfTheSPL.ToString());
                    foreach (quantifiedProperty p in f.listOfQuantifiedProperties)
                    {
                        treeView3.Nodes[fid].Nodes.Add(p.propertyName + ":" + p.value + "%");
                    }
                    fid++;
                }
            }
            if (i == 1)
            {
                int cid = 0;
                foreach (string cat in listOfAvailableCategories)
                {
                    treeView3.Nodes.Add(cat);
                    int fid = 0;
                    foreach (quantifiedFeature f in listOfAvailableQuantifiedFeatures)
                    {
                        if (f.category.Equals(cat))
                        {
                            treeView3.Nodes[cid].Nodes.Add(f.featureName);
                            treeView3.Nodes[cid].Nodes[fid].Nodes.Add("AddedValue:" + f.addedValue.ToString());
                            treeView3.Nodes[cid].Nodes[fid].Nodes.Add("Occurencies in other products:" + f.occurenciesOfFeatureExistInOtherProductsOfTheSPL.ToString());
                            foreach (quantifiedProperty p in f.listOfQuantifiedProperties)
                            {
                                treeView3.Nodes[cid].Nodes[fid].Nodes.Add(p.propertyName + ":" + p.value + "%");
                            }
                            fid++;
                        }

                    }
                    cid++;
                }

            }
            if (i == 3)
            {
                int cid = 0;
                foreach (string cat in listOfAvailableCategories)
                {
                    treeView3.Nodes.Add(cat);
                    int fid = 0;
                    foreach (quantifiedFeature f in listOfSortedByAddedValueQuantifiedFeatures)
                    {
                        if (f.category.Equals(cat))
                        {
                            treeView3.Nodes[cid].Nodes.Add(f.featureName);
                            treeView3.Nodes[cid].Nodes[fid].Nodes.Add("AddedValue:" + f.addedValue.ToString());
                            treeView3.Nodes[cid].Nodes[fid].Nodes.Add("Occurencies in other products:" + f.occurenciesOfFeatureExistInOtherProductsOfTheSPL.ToString());
                            foreach (quantifiedProperty p in f.listOfQuantifiedProperties)
                            {
                                treeView3.Nodes[cid].Nodes[fid].Nodes.Add(p.propertyName + ":" + p.value + "%");
                            }
                            fid++;
                        }

                    }
                    cid++;
                }

            }
        }
        public int findQuartile(string featureName)
        {
            int q = -1;
            // for each 

            return q;
        }

       
         public double getMedian(double[] myArr)
        {
            //double[] myArr = new double[] { 1, 5, 3, 6, 4, 2 };
 
            myArr = myArr.OrderBy(i => i).ToArray();
            // or Array.Sort(myArr) for in-place sort
 
            int mid = myArr.Length / 2;
            double median;
 
            if (myArr.Length % 2 == 0)
            {
                //we know its even
                median = (myArr[mid] + myArr[mid - 1]) / 2.0;
            }
            else
            {
                //we know its odd
                median = myArr[mid];
            }
            return median;
         }
        


       

        public void loadProduct()
        {
            string productFileName = "./" +comboBox2.Text+".xml";
      
            fileExists = (System.IO.File.Exists(@productFileName) ? true : false);
            if (fileExists)
            {
                //load
                XmlDataDocument xmldoc1 = new XmlDataDocument();
                XmlNodeList xmlnode1;
                System.IO.StreamReader file1 = new System.IO.StreamReader(@productFileName);
                xmldoc1.Load(file1);
                file1.Close();


                xmlnode1 = xmldoc1.GetElementsByTagName("Feature");

                loadedProduct.deleteAllFeatures();

                for (int i = 0; i < xmlnode1.Count; i++)
                {

                    feature tmpFeature = new feature(xmlnode1[i].ChildNodes.Item(0).InnerText.Trim(), xmlnode1[i].ChildNodes.Item(1).InnerText.Trim());
                    //MessageBox.Show();
                    for (int ii = 0; ii <= xmlnode1[i].ChildNodes.Item(2).ChildNodes.Count - 1; ii++)
                    {

                        tmpFeature.addProperty(xmlnode1[i].ChildNodes.Item(2).ChildNodes.Item(ii).ChildNodes.Item(0).InnerText.Trim(), xmlnode1[i].ChildNodes.Item(2).ChildNodes.Item(ii).ChildNodes.Item(1).InnerText.Trim());
                    }
                    loadedProduct.addFeature(tmpFeature);
                        
                }

                displayProductFeatures(comboBox5.SelectedIndex);

                //load Objectives
                //load
                XmlDataDocument xmldoc2 = new XmlDataDocument();
                XmlNodeList xmlnode2;
                System.IO.StreamReader file2 = new System.IO.StreamReader(@productFileName);
                xmldoc2.Load(file2);
                file2.Close();

                xmlnode2 = xmldoc2.GetElementsByTagName("CategoryObjectives");

                listOfObjectives.Clear();
                for (int i = 0; i < xmlnode2.Count ; i++)
                {
                    Form3.categoryConstrain cc=new Form3.categoryConstrain();
                    cc.categoryName = xmlnode2[i].ChildNodes.Item(0).InnerText.Trim();
                    cc.importance= Int32.Parse( xmlnode2[i].ChildNodes.Item(1).InnerText.Trim());
                    cc.minNumberOfInstancesOfThisCategory= Int32.Parse(xmlnode2[i].ChildNodes.Item(2).InnerText.Trim());
                    cc.maxNumberOfInstancesOfThisCategory= Int32.Parse(xmlnode2[i].ChildNodes.Item(3).InnerText.Trim());
                    cc.multipleInstancesOfTheSameFeature = Int32.Parse(xmlnode2[i].ChildNodes.Item(4).InnerText.Trim());
                    if (xmlnode2[i].ChildNodes.Item(5).InnerText.Trim().ToLower().Equals("false")) { cc.favourFeaturesExistInOtherProducts = false; } else { cc.favourFeaturesExistInOtherProducts = true; }
                    if (xmlnode2[i].ChildNodes.Item(6).InnerText.Trim().Length > 0)
                    {
                        //   MessageBox.Show(xmlnode2[i].ChildNodes.Item(6).InnerText.Trim());
                       
                        for (int ii = 0; ii < xmlnode2[i].ChildNodes.Item(6).ChildNodes.Count; ii++)
                        {
                            //feature properties objectives
                            Form3.objectives ooo = new Form3.objectives();
                            ooo.propertyName = xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(0).InnerText.Trim();
                            ooo.importance =Int32.Parse(xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(1).InnerText.Trim());
                            ooo.type = Int32.Parse(xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(2).InnerText.Trim());
                            ooo.numeric1 = Int32.Parse(xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(3).InnerText.Trim());
                            ooo.numeric2 = Int32.Parse(xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(4).InnerText.Trim());
                            ooo.txt1 = xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(5).InnerText.Trim();
                            ooo.txt2 = xmlnode2[i].ChildNodes.Item(6).ChildNodes.Item(ii).ChildNodes.Item(6).InnerText.Trim();
                            cc.listOfFeaturePropertiesObjectives.Add(ooo);
                        }
                    }

                    //category properties objectives
                    if (xmlnode2[i].ChildNodes.Item(7).InnerText.Trim().Length > 0)
                    {
                        for (int ii = 0; ii < xmlnode2[i].ChildNodes.Item(7).ChildNodes.Count; ii++)
                        {
                            //feature properties objectives
                            Form3.categoryPropertyConstrain cpc = new Form3.categoryPropertyConstrain();

                            cpc.propertyName = xmlnode2[i].ChildNodes.Item(7).ChildNodes.Item(ii).ChildNodes.Item(0).InnerText.Trim();
                            cpc.type = Int32.Parse(xmlnode2[i].ChildNodes.Item(7).ChildNodes.Item(ii).ChildNodes.Item(1).InnerText.Trim());
                            cpc.num1 = Int32.Parse(xmlnode2[i].ChildNodes.Item(7).ChildNodes.Item(ii).ChildNodes.Item(2).InnerText.Trim());
                            cpc.num2 = Int32.Parse(xmlnode2[i].ChildNodes.Item(7).ChildNodes.Item(ii).ChildNodes.Item(3).InnerText.Trim());
                            cc.listOfCategoryPropertiesObjectives.Add(cpc);
                            
                        }
                    }


                    listOfObjectives.Add(cc);

                }

                // end of loading objectives

            }
            getProductValueANDNoOfFeatures();
        }
        public void addCategory(string input)
        {
            foreach (string cat in listOfAvailableCategories)
            {
                if (cat.Equals(input)) return;
            }
            listOfAvailableCategories.Add(input);
        }
        public void addProductCategory(string input)
        {
            foreach (string cat in productCategories)
            {
                if (cat.Equals(input)) return;
            }
            productCategories.Add(input);
        }
        public void loadAvailableFeatures()
        {
            fileExists = (System.IO.File.Exists(@"./features.xml") ? true : false);
            if (fileExists)
            {
                //load
                XmlDataDocument xmldoc1 = new XmlDataDocument();
                XmlNodeList xmlnode1;
                System.IO.StreamReader file1 = new System.IO.StreamReader(@"./features.xml");
                xmldoc1.Load(file1);
                file1.Close();

                xmlnode1 = xmldoc1.GetElementsByTagName("Feature");
                listOfAvailableFeatures.Clear();
                for (int i = 0; i <= xmlnode1.Count - 1; i++)
                {

                    feature tmpFeature = new feature(xmlnode1[i].ChildNodes.Item(0).InnerText.Trim(), xmlnode1[i].ChildNodes.Item(1).InnerText.Trim());
                 //   MessageBox.Show(tmpFeature.featureName+tmpFeature.category);
                    for (int ii = 0; ii <= xmlnode1[i].ChildNodes.Item(2).ChildNodes.Count - 1; ii++)
                    {
                        
                        tmpFeature.addProperty(xmlnode1[i].ChildNodes.Item(2).ChildNodes.Item(ii).ChildNodes.Item(0).InnerText.Trim(), xmlnode1[i].ChildNodes.Item(2).ChildNodes.Item(ii).ChildNodes.Item(1).InnerText.Trim());
                    }
                    listOfAvailableFeatures.Add(tmpFeature);
                    // if category is new then add it to the list of categories 
                    addCategory(tmpFeature.category);
               

                }

                displayAvailableFeatures(0);
            }
            else
            {
                using (StreamWriter outputFile = new StreamWriter(@"./features.xml"))
                {
                  
                    outputFile.WriteLine("<Features>");
                    
                    outputFile.WriteLine("</Features>");
                }
                    
            }
            }

        public Form1()
        {

            InitializeComponent();
            comboBox3.SelectedIndex = 0;
            loadSPLs();
            loadAvailableFeatures();
            comboBox4.SelectedIndex = 0;
            comboBox5.SelectedIndex = 0;
            comboBox6.SelectedIndex = 0;







        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        public void saveSPLs()
        {
            using (StreamWriter outputFile = new StreamWriter(filePath))
            {
                outputFile.WriteLine("<User>");
                foreach (SPL row in ListOfSPLs)
                {
                    outputFile.WriteLine("<SPL><SPLName>" + row.SPLName + "</SPLName>");
                    outputFile.WriteLine("<Products>");
                    foreach (product p in row.ListOfProducts) {
                        outputFile.WriteLine("<Product>");
                        outputFile.WriteLine("<ProductName>"+p.name+"</ProductName>");
                        outputFile.WriteLine("</Product>");
                    }
                    outputFile.WriteLine("</Products>");
                    outputFile.WriteLine("</SPL>");
                }
                outputFile.WriteLine("</User>");
                outputFile.Close();
            }

        }
        
        private void button1_Click_1(object sender, EventArgs e)
        {
            ListOfSPLs.Add(new SPL(comboBox1.Text));
            saveSPLs();
            loadSPLs();



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        
            SPLComboboxIndex = comboBox1.SelectedIndex;
            
            loadProducts();
            //if (comboBox1.SelectedIndex)
            label2.Visible = true;
            comboBox2.Visible = true;
            button3.Visible = true;

            if (comboBox2.SelectedIndex > -1)
            {
                button4.Visible = true;
                button15.Visible = true;
            }
            else
            {
                button4.Visible = false;
                button15.Visible = false;
            }


        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            treeView2.Nodes.Clear();
            loadedProduct.ListOfFeatures.Clear(); 
            // load product
            ProductComboboxIndex = comboBox2.SelectedIndex;
            prevCombox2Text = comboBox2.Text;

            //if (comboBox1.SelectedIndex)
            label2.Visible = true;
            comboBox2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button15.Visible = true;

            // Load product features
            loadedProduct.name = comboBox2.SelectedText;
            loadedProduct.SPLName = comboBox2.SelectedText;
            loadProduct();
            //load buttons
            if (comboBox2.SelectedIndex>-1)
            {
                button4.Visible = true;
                button15.Visible = true;
            }
            else
            {
                button4.Visible = false;
                button15.Visible = false;
            }


        }
        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            ListOfSPLs.RemoveAt(comboBox1.SelectedIndex);

            saveSPLs();
            loadSPLs();



        }
        int ProductComboboxIndex = -1;
        int SPLComboboxIndex = -1;
        private void button14_Click(object sender, EventArgs e)
        {
          
            ListOfSPLs[SPLComboboxIndex].SPLName = comboBox1.Text;
            saveSPLs();
            loadSPLs();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            using (StreamWriter outputFile = new StreamWriter(@"./"+comboBox2.Text.Trim()+".xml"))
            {
                outputFile.WriteLine("<Product>");
                outputFile.WriteLine("<ProductName>"+comboBox2.Text.Trim()+ "</ProductName>");
                outputFile.WriteLine("<SPLIdex>" + comboBox1.SelectedIndex.ToString() + "</SPLIdex>");
                outputFile.WriteLine("<Features></Features>");
                outputFile.WriteLine("</Product>");
                outputFile.Close();
            }
            ListOfSPLs[SPLComboboxIndex].ListOfProducts.Add(new product(comboBox2.Text));
            saveSPLs();
            loadProducts();
            prevCombox2Text = comboBox2.Text;
            button4.Visible = true;
            button15.Visible = true;
            MessageBox.Show("A new product called " + comboBox2.Text + " has been created");
        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }
        private string prevCombox2Text = "";
        private void button15_Click(object sender, EventArgs e)
        {
            System.IO.File.Move(@".\" + prevCombox2Text + ".xml", @".\" + comboBox2.Text.Trim()+".xml"); // rename associated file

            foreach (product p in ListOfSPLs[SPLComboboxIndex].ListOfProducts )
            {
                if (p.name.Equals(prevCombox2Text)) { p.name = comboBox2.Text.Trim(); }

            }

           

            saveSPLs();
            loadSPLs();
            loadProducts();
            MessageBox.Show("A product called " + prevCombox2Text +" has been renamed to "+comboBox2.Text );
            prevCombox2Text = comboBox2.Text;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.IO.File.Delete(@".\"+comboBox2.Text.Trim()+".xml");//delete assosiated file
            ListOfSPLs[SPLComboboxIndex].deleteProduct(comboBox2.Text);
            saveSPLs();
            loadSPLs();
            loadProducts();
            MessageBox.Show("A product called "+prevCombox2Text+" has been deleted");
            button4.Visible = false;
            button15.Visible = false;
            treeView2.Nodes.Clear();
            comboBox2.SelectedIndex = -1;
            comboBox2.Text = "";
            getProductValueANDNoOfFeatures();
        }
        int productCombobox2Index = -1;
     
        private void button6_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();

            f2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
        public void exportQuantifiedFeatures()
        {
            if (listOfAvailableQuantifiedFeatures.Count()>0&&comboBox1.SelectedIndex>-1)
            {
                string productFileName = "./" + comboBox1.Text + ".xml";
                using (StreamWriter outputFile = new StreamWriter(@productFileName))
                {
                    outputFile.WriteLine("<QuantifiedFeatures>");
                    outputFile.WriteLine("<SPL>" + comboBox1.Text + "</SPL>");
                    outputFile.WriteLine("<DATE>" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "</DATE>");
                    foreach (quantifiedFeature qf in listOfAvailableQuantifiedFeatures) {
                        outputFile.WriteLine("<Feature>");
                        outputFile.WriteLine("<FeatureName>"+qf.featureName+"</FeatureName>");
                        outputFile.WriteLine("<FeatureCategory>" + qf.category + "</FeatureCategory>");
                        outputFile.WriteLine("<FeatureAddedValue>" + qf.addedValue + "</FeatureAddedValue>");
                        outputFile.WriteLine("<QuantifiedProperties>");
                        foreach (quantifiedProperty qp in qf.listOfQuantifiedProperties)
                        {
                            outputFile.WriteLine("<PropertyName>" + qp.propertyName + "</PropertyName>");
                            outputFile.WriteLine("<PropertyValue>" + qp.value + "</PropertyValue>");

                        }
                        outputFile.WriteLine("</QuantifiedProperties>");
                        outputFile.WriteLine("</Feature>");
                    }
                    outputFile.WriteLine("</QuantifiedFeatures>");
                }
                    MessageBox.Show("Quantified features have been exported to file "+comboBox1.Text+".xml");
            }
            else
            {
                MessageBox.Show("There are no quantified features to export");
            }

        }

        public void saveProduct()
        {
            // save product features
            if (comboBox2.SelectedIndex > -1)
            {
                string productFileName = "./" + comboBox2.Text + ".xml";
                using (StreamWriter outputFile = new StreamWriter(@productFileName))
                {
                    outputFile.WriteLine("<Product>");
                    outputFile.WriteLine("<Name>" + comboBox2.Text + "</Name>");
                    outputFile.WriteLine("<SPLName>" + comboBox1.Text + "</SPLName>");
                    outputFile.WriteLine("<Objectives>");
                    foreach (Form3.categoryConstrain cc in listOfObjectives)
                    {
                        outputFile.WriteLine("<CategoryObjectives>");
                        outputFile.WriteLine("<categoryName>" + cc.categoryName + "</categoryName>");
                        outputFile.WriteLine("<categoryImportance>" + cc.importance.ToString() + "</categoryImportance>");
                        outputFile.WriteLine("<minNumberOfInstancesOfThisCategory>" + cc.minNumberOfInstancesOfThisCategory.ToString() + "</minNumberOfInstancesOfThisCategory>");
                        outputFile.WriteLine("<maxNumberOfInstancesOfThisCategory>" + cc.maxNumberOfInstancesOfThisCategory.ToString() + "</maxNumberOfInstancesOfThisCategory>");
                        outputFile.WriteLine("<multipleInstancesOfTheSameFeature>" + cc.multipleInstancesOfTheSameFeature.ToString() + "</multipleInstancesOfTheSameFeature>");
                        outputFile.WriteLine("<favourFeaturesThatExistInOtherProductsOfTheSPL>" + cc.favourFeaturesExistInOtherProducts.ToString() + "</favourFeaturesThatExistInOtherProductsOfTheSPL>");

                        outputFile.WriteLine("<FeaturesPropertyObjectives>");
                        foreach (Form3.objectives o in cc.listOfFeaturePropertiesObjectives)
                        {
                            outputFile.WriteLine("<FeaturePropertyObjective>");
                            outputFile.WriteLine("<propertyName>" + o.propertyName + "</propertyName>");
                            outputFile.WriteLine("<featureObjectiveImportance>" + o.importance.ToString() + "</featureObjectiveImportance>");
                            outputFile.WriteLine("<featureObjectiveType>" + o.type.ToString() + "</featureObjectiveType>");
                            outputFile.WriteLine("<featureObjectiveNumeric1>" + o.numeric1.ToString() + "</featureObjectiveNumeric1>");
                            outputFile.WriteLine("<featureObjectiveNumeric2>" + o.numeric2.ToString() + "</featureObjectiveNumeric2>");
                            outputFile.WriteLine("<featureObjectiveTxt1>" + o.txt1 + "</featureObjectiveTxt1>");
                            outputFile.WriteLine("<featureObjectiveTxt2>" + o.txt2 + "</featureObjectiveTxt2>");
                            outputFile.WriteLine("</FeaturePropertyObjective>");
                        }
                        outputFile.WriteLine("</FeaturesPropertyObjectives>");

                        outputFile.WriteLine("<CategoryPropertyObjectives>");
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            outputFile.WriteLine("<CPO>");
                            outputFile.WriteLine("<CPOpropertyName>" + cpc.propertyName + "</CPOpropertyName>");
                            outputFile.WriteLine("<CPOType>" + cpc.type.ToString() + "</CPOType>");
                            outputFile.WriteLine("<CPONumeric1>" + cpc.num1.ToString() + "</CPONumeric1>");
                            outputFile.WriteLine("<CPONumeric2>" + cpc.num2.ToString() + "</CPONumeric2>");
                            outputFile.WriteLine("</CPO>");
                        }
                        outputFile.WriteLine("</CategoryPropertyObjectives>");

                        outputFile.WriteLine("</CategoryObjectives>");
                    }
                    outputFile.WriteLine("</Objectives>");
                    foreach (feature row in loadedProduct.ListOfFeatures)
                    {
                        outputFile.WriteLine("<Feature>");
                        outputFile.WriteLine("<Name>" + row.featureName + "</Name>");
                        outputFile.WriteLine("<Category>" + row.category + "</Category>");
                        outputFile.WriteLine("<Properties>");
                        foreach (featureProperty rowP in row.ListOfProperties)
                        {
                            outputFile.WriteLine("<Property>");
                            outputFile.WriteLine("<PropertyName>" + rowP.propertyName + "</PropertyName>");
                            outputFile.WriteLine("<PropertyValue>" + rowP.propertyValue + "</PropertyValue>");
                            outputFile.WriteLine("</Property>");
                        }
                        outputFile.WriteLine("</Properties>");
                        outputFile.WriteLine("</Feature>");

                    }
                    outputFile.WriteLine("</Product>");
                    outputFile.Close();
                }
                MessageBox.Show("Product Saved");
            }
            else
            {
                MessageBox.Show("No product selected");
            }
        }
    
      

        private void button10_Click(object sender, EventArgs e)
        {
           

            
            if (comboBox2.SelectedIndex > -1)
            {
                Form3 f3 = new Form3(listOfAvailableFeatures.First<feature>().listAvailableProperties(), listOfAvailableCategories, loadedProduct,listOfAvailableFeatures);

                f3.Show();
            }
            else { MessageBox.Show("No product selected"); }


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        public string displayAllObjectives(List<Form3.categoryConstrain> ListOfCC)
        {
            string output = "";
            foreach (Form3.categoryConstrain cc in ListOfCC)
            {

                output = output + Environment.NewLine + Environment.NewLine + cc.categoryName;

             //   if (cc.categoryName.Equals("Global"))
               // {
                    output = output + Environment.NewLine + "Multiple instances of the same feature:" + cc.multipleInstancesOfTheSameFeature.ToString() + Environment.NewLine + "Favour features that exist in other products of the SPL:" + cc.favourFeaturesExistInOtherProducts.ToString();

                //}
                output = output + Environment.NewLine + "Min number of features:" + cc.minNumberOfInstancesOfThisCategory + " Max number of features:" + cc.maxNumberOfInstancesOfThisCategory;
                if (!cc.categoryName.Equals("Global"))
                {
                    output = output + "Importance:" + cc.importance.ToString();
                }
                output = output + Environment.NewLine + "Category Property Constraints:";
                foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                {



                    if (cpc.type == 1)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " less than ";
                    }
                    else if (cpc.type == 2)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " more than ";
                    }
                    else if (cpc.type == 3)
                    {
                        output = output + Environment.NewLine + cpc.propertyName + " between "+cpc.num2+" and ";
                    }
                  
                    output = output + cpc.num1;


                }
                output = output + Environment.NewLine + "Feature Property Constraints:";
                foreach (Form3.objectives o in cc.listOfFeaturePropertiesObjectives)
                {
                    output = output + Environment.NewLine + o.propertyName + " ";
                    if (o.type == 1)
                    {
                        output = output + "Include:" + o.txt1 + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 2)
                    {
                        output = output + "Exclude:" + o.txt1 + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 3)
                    {
                        output = output + "Include:" + o.txt1 + "AND Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 4)
                    {
                        output = output + "Must Include:" + o.txt1 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 5)
                    {
                        output = output + "Must Exclude:" + o.txt1 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 6)
                    {
                        output = output + "Must Include:" + o.txt1 + "AND Must Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 7)
                    {
                        output = output + "Must Include:" + o.txt1 + "AND Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }
                    else if (o.type == 8)
                    {
                        output = output + "Include:" + o.txt1 + "AND Must Exclude: " + o.txt2 + " Importance:" + o.importance.ToString();
                    }



                    else if (o.type == 9)
                    {
                        output = output + "Equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 10)
                    {
                        output = output + "Approximately equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 11)
                    {
                        output = output + "Not equal to:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 12)
                    {
                        output = output + "upto (Higher better):" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 13)
                    {
                        output = output + "upto (Lower better):" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 15)
                    {
                        output = output + "Less than:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 14)
                    {
                        output = output + "More than:" + o.numeric1.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 16)
                    {
                        output = output + "Between " + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 17)
                    {
                        output = output + "Between (Higher better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 18)
                    {
                        output = output + "Between (Lower better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 19)
                    {
                        output = output + "Above (Higher better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }
                    else if (o.type == 20)
                    {
                        output = output + "Above (Lower better)" + o.numeric1.ToString() + " AND " + o.numeric2.ToString() + " Importance:" + o.importance.ToString();

                    }


                }

            }
            return output;

        }
        private void button17_Click(object sender, EventArgs e)
        {
            

            MessageBox.Show(displayAllObjectives(listOfObjectives));
        }
        public int getFeatureIndex(string name, List<feature> listOfFeatures)
        {
            int ii=0;
            foreach (feature f in listOfFeatures)
            {
                if (f.featureName.Equals(name)) { return ii; }
                ii++;
            }
            return -1;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            int ni = 0;
            if (comboBox4.SelectedIndex == 1) { ni= 1; } else { ni = 0; }

            try
            {
               if ((treeView1.SelectedNode.Level == ni)&&(comboBox2.SelectedIndex>-1))
                {
                    loadedProduct.ListOfFeatures.Add (listOfAvailableFeatures[getFeatureIndex(treeView1.SelectedNode.Text,listOfAvailableFeatures)]);
                    displayProductFeatures(comboBox5.SelectedIndex);
                    MessageBox.Show("Feature "+ treeView1.SelectedNode.Text+" has been added to product "+comboBox2.Text);
                }
                else
                {

                    MessageBox.Show("Please select a feature. Not a property. Also ensure that you have selected a product.");
                }
               
            }
            catch { MessageBox.Show("No node selected"); }
            getProductValueANDNoOfFeatures();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int ni = 0;
            if (comboBox5.SelectedIndex == 1) { ni = 1; } else { ni = 0; }
            try
            {
                if ((treeView2.SelectedNode.Level == ni) && (comboBox2.SelectedIndex > -1))
                {
                    string fn = treeView2.SelectedNode.Text;
                    loadedProduct.ListOfFeatures.RemoveAt(getFeatureIndex(fn,loadedProduct.ListOfFeatures));
                    displayProductFeatures(comboBox5.SelectedIndex);
                    MessageBox.Show("Feature " + fn + " has been removed from product " + comboBox2.Text);
                }
                else
                {

                    MessageBox.Show("Please select a feature. Not a property. Also ensure that you have selected a product.");
                }

            }
            catch { MessageBox.Show("No node selected"); }
            getProductValueANDNoOfFeatures();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            displayAvailableFeatures(comboBox4.SelectedIndex);
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            displayProductFeatures( comboBox5.SelectedIndex);
        }
        bool v1s = false;
        private void button18_Click(object sender, EventArgs e)
        {
            if (!v1s)
            {
                button18.Text = "U";
                treeView1.Sort();
                v1s = true;
            }
            else
            {
                button18.Text = "A";
                treeView1.Sorted = false;
                v1s = false;
            }
        }
        public void importAvailableFeatures()
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string file = openFileDialog1.FileName;
                try
                {

                    File.Copy(Path.Combine(file), Path.Combine(@"./features.xml"), true);
                    loadAvailableFeatures();
                    displayAvailableFeatures(0);
                    comboBox4.SelectedIndex = 0;
                }
                catch (IOException)
                {
                }
            }

        }
        private void button13_Click(object sender, EventArgs e)
        {
            importAvailableFeatures();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            treeView1.Sorted = false;
            loadAvailableFeatures();
            displayAvailableFeatures(0);
            comboBox4.SelectedIndex = 0;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            treeView2.Sorted = false;
            loadProduct();
           displayProductFeatures(0);
            comboBox5.SelectedIndex = 0;
            getProductValueANDNoOfFeatures();
        }
        bool v2s = false;
        private void button21_Click(object sender, EventArgs e)
        {
            if (!v2s)
            {
                button21.Text = "U";
                treeView2.Sort();
                v2s = true;
            }
            else
            {
                button21.Text = "A";
                treeView2.Sorted = false;
                v2s = false;
            }
        }
        public class propertyWithValue
        {
            public string property;
            public Decimal value;
           public propertyWithValue(string n,Decimal v)
            {
                property = n;
                value = v;
            }
        }
        public List<propertyWithValue> listOfSelectedPropertiesMaxValue = new List<propertyWithValue>();
        public Decimal getSelectedPropertyMaxValue(string propertyName)
        {
            Decimal val = -999999999;

            foreach (propertyWithValue pv in listOfSelectedPropertiesMaxValue)
            {
                if (pv.property.Equals(propertyName))
                {
                    return pv.value;
                }

            }

            return val;

        }
        public List<propertyWithValue> listOfSelectedPropertiesMinValue = new List<propertyWithValue>();
        public Decimal getSelectedPropertyMinValue(string propertyName)
        {
            Decimal val = -999999999;

            foreach (propertyWithValue pv in listOfSelectedPropertiesMinValue)
            {
                if (pv.property.Equals(propertyName))
                {
                    return pv.value;
                }

            }

            return val;

        }
        // the following method will return a feature based on its rank it terms of property value
        /*  public List<feature> getFeatureWithMaxPropertyVal(string propertyName)
          {
              List<feature> featuresSortedByAddedValueANDMaxPropertyValue = new List<feature>();


              for (int i=0;i< listOfSortedByAddedValueQuantifiedFeatures.Count();i++)
              {
                  feature featureWithMaxPropertyVal = getAvailableFeature(listOfSortedByAddedValueQuantifiedFeatures[i].featureName);

                  for (int ii=0;ii< listOfSortedByAddedValueQuantifiedFeatures.Count(); ii++)
                  {
                      if (Decimal.Parse(featureWithMaxPropertyVal.getPropertyValue(propertyName)) < Decimal.Parse(getAvailableFeature(listOfSortedByAddedValueQuantifiedFeatures[ii].featureName).getPropertyValue(propertyName)))
                      {
                          featureWithMaxPropertyVal = getAvailableFeature(listOfSortedByAddedValueQuantifiedFeatures[ii].featureName);
                      }

                  }
                  featuresSortedByAddedValueANDMaxPropertyValue.Add(featureWithMaxPropertyVal);

              }


              return featuresSortedByAddedValueANDMaxPropertyValue;
          }*/

        // the following method will return a feature based on its rank it terms of property value

        public List<quantifiedFeature> getListOfFeaturesSortedByMaxPropertyVal(List<quantifiedFeature> listOfAvailableQuantifiedFeatures, string propertyName)
        {
            List<quantifiedFeature> tmpListOfQuantifiedFeatures = new List<quantifiedFeature>();
            List<quantifiedFeature> listOfSortedQuantifiedFeatures = new List<quantifiedFeature>();
            foreach (quantifiedFeature q in listOfAvailableQuantifiedFeatures)
            {
                tmpListOfQuantifiedFeatures.Add(q);
            }

            while (listOfSortedQuantifiedFeatures.Count() < listOfAvailableQuantifiedFeatures.Count())
            {
                decimal tempMaxPropertyValue = -2m;
                int tempMaxFeatureIndex = 0;
                int currentFeatureIndex = 0;
                foreach (quantifiedFeature qf in tmpListOfQuantifiedFeatures)
                {
                    if (getAvailableFeature(qf.featureName).getNumericPropertyValue(propertyName) > tempMaxPropertyValue)
                    {
                        tempMaxPropertyValue = getAvailableFeature(qf.featureName).getNumericPropertyValue(propertyName);
                        tempMaxFeatureIndex = currentFeatureIndex;
                    }

                    currentFeatureIndex++;

                }
                listOfSortedQuantifiedFeatures.Add(tmpListOfQuantifiedFeatures.ElementAt(tempMaxFeatureIndex));
                tmpListOfQuantifiedFeatures.RemoveAt(tempMaxFeatureIndex);
            }
            return listOfSortedQuantifiedFeatures;
        }
        public decimal getPercentange(decimal min, decimal max, decimal val) // val should be within min and max and min should be less than max
        {
           // MessageBox.Show("min:"+min.ToString()+", max:"+max.ToString()+", val:"+val.ToString());
            decimal output = -1;
            if (val>max||val<min)
            {
                return -1;
            }
            max = max - min;
            val = val - min;
            if (max == 0)
            {
                return 0;
            }
            output = (val / max) * 100m;
            return output;
        }
        public void setMaxANDMinPropertyValuesQF(List<quantifiedFeature> listOfFeatures)
        {
            listOfSelectedPropertiesMaxValue.Clear();
            listOfSelectedPropertiesMinValue.Clear();
            foreach (Form3.categoryConstrain cc in listOfObjectives)
            {
                foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                {
                    listOfSelectedPropertiesMaxValue.Add(new propertyWithValue(cpc.propertyName,-99999m));
                    listOfSelectedPropertiesMinValue.Add(new propertyWithValue(cpc.propertyName, 99999m));
                }
            }
            foreach (quantifiedFeature qf in listOfFeatures)
            {
                foreach (feature f in listOfAvailableFeatures)
                {
                    if (f.featureName.Equals(qf.featureName))
                    {// do the max
                        foreach (propertyWithValue pv in listOfSelectedPropertiesMaxValue)
                        {
                            if (pv.value<f.getNumericPropertyValue(pv.property))
                            {
                                pv.value = f.getNumericPropertyValue(pv.property);
                            }

                        }
                        // do the min
                        foreach (propertyWithValue pv in listOfSelectedPropertiesMinValue)
                        {
                            if (pv.value > f.getNumericPropertyValue(pv.property))
                            {
                                pv.value = f.getNumericPropertyValue(pv.property);
                            }

                        }
                    }
                }
            }
            
            

        }
        private void button9_Click(object sender, EventArgs e)
        {
            button9.Enabled = false;

            string outputMessage = "";
            // check if there are quantified features.
            if (listOfAvailableQuantifiedFeatures.Count()==0)
            {
                MessageBox.Show("There are no quanitifed features");
                button9.Enabled = true;
                return;

            }
            int violation = productConstrainViolation(loadedProduct, false);
            if (violation>0&&violation!=7&&violation!=2) // if there is a violation which is not the max property value or the number of features
            {
                productConstrainViolation(loadedProduct, true);
                button9.Enabled = true;
                return;
            }
            int featuresAdded = 0;
            //create a local copy of the list of sorted by added value list of available quantified features
            List<quantifiedFeature> tempListOfavailableQF = new List<quantifiedFeature>();
            foreach (quantifiedFeature qf in listOfSortedByAddedValueQuantifiedFeatures)
            {
                if (qf.addedValue > 0m)
                {
                    Form3.categoryConstrain cc = null;
                    foreach (Form3.categoryConstrain c in listOfObjectives)
                    {
                        if (c.categoryName.Equals(qf.category))
                        {
                            cc = c;
                        }
                    }
                    if (cc != null && cc.multipleInstancesOfTheSameFeature > 1)
                    {
                        for (int i=0;i<cc.multipleInstancesOfTheSameFeature;i++)
                        {
                            tempListOfavailableQF.Add(qf);
                        }
                    }
                    else
                    {
                        tempListOfavailableQF.Add(qf);
                    }
                }

            }
            // create a temp product
            product tempProduct = new product(loadedProduct.name);
            foreach (feature f in loadedProduct.ListOfFeatures) {
                tempProduct.addFeature(f);
            }              

            string startTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")+":"+ DateTime.Now.Millisecond;

            
            if (comboBox3.SelectedIndex == 0)// if auto
            {
               
                if (tempListOfavailableQF.Count()>21)
                {// either falcon or jaguar
                    bool j = false;
                    foreach (Form3.categoryConstrain cpc in listOfObjectives)// if property constrains are set
                    {
                        if (cpc.listOfCategoryPropertiesObjectives.Count()>0)
                        {
                            j = true;
                        }
                    }
                    if (j)
                    {
                        comboBox3.SelectedIndex = 3;// jaguar
                    }
                    else
                    {
                        comboBox3.SelectedIndex = 1;// falcon
                    }

                    
                } else
                {
                    comboBox3.SelectedIndex = 2;// snail
                }


            }

            if (comboBox3.SelectedIndex == 3) // jaguar feature selection algorithm
            {
                // if no property objectives, then this algorithm can not be used 
                bool j = false;
                foreach (Form3.categoryConstrain cpc in listOfObjectives)// if property constrains are set
                {
                    if (cpc.listOfCategoryPropertiesObjectives.Count() > 0)
                    {
                        j = true;
                    }
                }
                if (j == false)
                {
                    MessageBox.Show("No property constraints set, either set property constraints or select another algorithm.");
                    button9.Enabled = true;
                    return;
                }

                // manipulate the list of candidateQuatinitiedFeatures

                // set the min and max property values
                setMaxANDMinPropertyValuesQF(tempListOfavailableQF);

                //create a list of property constrains
                List<Form3.categoryPropertyConstrain> ListOfCPCs = new List<Form3.categoryPropertyConstrain>();
                
               

                foreach (quantifiedFeature qf in tempListOfavailableQF)
                {
                 
                    
                    // get category constain for this feature
                    Form3.categoryConstrain scc = new Form3.categoryConstrain();
                    scc.categoryName = "";
                    foreach (Form3.categoryConstrain catcon in listOfObjectives)
                    {
                        if (catcon.categoryName.Equals(qf.category))
                        {
                            if (catcon.listOfCategoryPropertiesObjectives.Count()>0) {
                                scc = catcon;
                            }
                        }
                    }
                    // if there is no category constain, check for global
                    if (scc.categoryName.Length<1)
                    {
                        foreach (Form3.categoryConstrain catcon in listOfObjectives)
                        {
                            if (catcon.categoryName.Equals("Global"))
                            {
                                if (catcon.listOfCategoryPropertiesObjectives.Count() > 0)
                                {
                                    scc = catcon;
                                }
                            }
                        }

                    }

                    if (scc.categoryName.Length < 1)
                    {
                        MessageBox.Show("An error occured while proccessing feature "+qf.featureName+". There are no global and no category property constraints defined for category:" + qf.category);
                        button9.Enabled = true;
                        return;
                    }
                    // foreach category property constrain
                    Decimal featureCost=0m; // this is the selection cost of the feature
                    foreach (Form3.categoryPropertyConstrain cpc in scc.listOfCategoryPropertiesObjectives)
                    {
                       

                        Decimal propertyCost = 0m;
                        // calculate the selection cost from this property
                        // check the constrain to select a formula
                        if (cpc.type==1) // if less than use the upto (lower better)
                        {
                            //propertyCost = percentageOfProximity(getSelectedPropertyMinValue(cpc.propertyName), cpc.num1, getAvailableFeature(qf.featureName).getNumericPropertyValue(cpc.propertyName), 'h', 'f');
                            propertyCost= getPercentange(getSelectedPropertyMinValue(cpc.propertyName), getSelectedPropertyMaxValue(cpc.propertyName),getAvailableFeature(qf.featureName).getNumericPropertyValue(cpc.propertyName));
                            if (propertyCost > 100) propertyCost = 100;
                        }
                        else if (cpc.type == 2) // if more than use the equal and above
                        {
                            propertyCost = getPercentange(getSelectedPropertyMinValue(cpc.propertyName), getSelectedPropertyMaxValue(cpc.propertyName), getAvailableFeature(qf.featureName).getNumericPropertyValue(cpc.propertyName));

                        }
                        
                        featureCost = featureCost + propertyCost;
                       // MessageBox.Show("property cost:"+ propertyCost);
                    }

                
                        featureCost = featureCost / scc.listOfCategoryPropertiesObjectives.Count();
                    if (featureCost==0) { featureCost = 0.01m; }
                        qf.AddedValuePerCostUnit =  qf.addedValue/ featureCost;

                     // MessageBox.Show("AddedValue:"+qf.addedValue + ", propertyCost:" + featureCost+ ",AddedValuePerCostUnit:"+ qf.AddedValuePerCostUnit);
                
                }

                // re-sort the list of quantified features
                tempListOfavailableQF = sortAvailableQuantifiedFeaturesByCostDividedByAddedValue(tempListOfavailableQF);



                // do the selection
                // first satisfy the minimum number of features criteria 
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if ((!cc.categoryName.Equals("Global")) && cc.minNumberOfInstancesOfThisCategory > -1)
                    {
                        int numberOfFeaturesAddedForThisCategory = 0;
                        foreach (quantifiedFeature qf in tempListOfavailableQF)
                        {
                            if (qf.category.Equals(cc.categoryName))
                            {
                                // check if feature violete any constrain
                                if (featureAdditionNoConstrainViolation(qf, tempProduct))
                                {
                                    // add feature to the product
                                    tempProduct.addFeature(getAvailableFeature(qf.featureName));
                                    featuresAdded++;
                                    numberOfFeaturesAddedForThisCategory++;
                                    if (numberOfFeaturesAddedForThisCategory >= cc.minNumberOfInstancesOfThisCategory)
                                    {
                                        break;
                                    }
                                }
                            }

                        }
                    }

                }

                // Try to satisfy the max property value constrains
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if (!cc.categoryName.Equals("Global"))
                    {
                        //  satisfy the different category max property constrains 
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            if (cpc.type == 2)
                            {
                                List<quantifiedFeature> MaxValQF = getListOfFeaturesSortedByMaxPropertyVal(tempListOfavailableQF, cpc.propertyName);
                                int MaxValQFIndex = 0;
                                while (tempProduct.getTotalValueForFeatureProperty(cpc.propertyName, cc.categoryName) <= cpc.num1)
                                {
                                    if (featureAdditionNoConstrainViolation(MaxValQF[MaxValQFIndex], tempProduct))
                                    {
                                        // add feature to the product
                                        tempProduct.addFeature(getAvailableFeature(MaxValQF[MaxValQFIndex].featureName));
                                        featuresAdded++;
                                    }
                                    MaxValQFIndex++;
                                    if (MaxValQFIndex >= MaxValQF.Count())
                                    {
                                        MessageBox.Show("Feature Selection Failed due to Max Value Constrain. Solution not possible.");
                                        button9.Enabled = true;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }

                // then use greedy to add the rest of the features based on their added value
                int numberOfCandidateFeatures = tempListOfavailableQF.Count();
                long c = 0;
                foreach (quantifiedFeature qf in tempListOfavailableQF)
                {
                    // the selection should stop, once the features with zero or less added value are reached
                    if (qf.addedValue <= 0m) { break; }

                    // check if feature violete any constrain
                    if (featureAdditionNoConstrainViolation(qf, tempProduct))
                    {
                        // add feature to the product
                        tempProduct.addFeature(getAvailableFeature(qf.featureName));
                        featuresAdded++;
                    }
                    c++;
                    Application.DoEvents();
                    label9.Text = "Completed:" + c.ToString() + "/" + numberOfCandidateFeatures.ToString();
                }

            }

            else if (comboBox3.SelectedIndex == 1) // falcon feature selection algorithm
            {
                // first satisfy the minimum number of features criteria 
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if ((!cc.categoryName.Equals("Global"))&& cc.minNumberOfInstancesOfThisCategory>-1)
                    {
                        int numberOfFeaturesAddedForThisCategory = 0;
                        foreach (quantifiedFeature qf in tempListOfavailableQF)
                        {
                            if (qf.category.Equals(cc.categoryName))
                            {
                                // check if feature violete any constrain
                                if (featureAdditionNoConstrainViolation(qf, tempProduct))
                                {
                                    // add feature to the product
                                    tempProduct.addFeature(getAvailableFeature(qf.featureName));
                                    featuresAdded++;
                                    numberOfFeaturesAddedForThisCategory++;
                                    if (numberOfFeaturesAddedForThisCategory>=cc.minNumberOfInstancesOfThisCategory)
                                    {
                                        break;
                                    }
                                }
                            }

                        }
                    }

                }



                // Try to satisfy the max property value constrains
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if (!cc.categoryName.Equals("Global"))
                    {
                        //  satisfy the different category max property constrains 
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            if (cpc.type==2)
                            {
                                List<quantifiedFeature> MaxValQF = getListOfFeaturesSortedByMaxPropertyVal(tempListOfavailableQF,cpc.propertyName);
                                int MaxValQFIndex = 0;
                                while (tempProduct.getTotalValueForFeatureProperty(cpc.propertyName, cc.categoryName) <= cpc.num1)
                                {
                                    if (featureAdditionNoConstrainViolation(MaxValQF[MaxValQFIndex], tempProduct))
                                    {
                                        // add feature to the product
                                        tempProduct.addFeature(getAvailableFeature(MaxValQF[MaxValQFIndex].featureName));
                                        featuresAdded++;
                                    }
                                    MaxValQFIndex++;
                                    if (MaxValQFIndex>= MaxValQF.Count())
                                    {
                                        MessageBox.Show("Feature Selection Failed due to Max Value Constrain. Solution not possible.");
                                        button9.Enabled = true;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }


                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if (cc.categoryName.Equals("Global"))
                    {
                        //  satisfy the different category max property constrains 
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            if (cpc.type == 2)
                            {
                                List<quantifiedFeature> MaxValQF = getListOfFeaturesSortedByMaxPropertyVal(tempListOfavailableQF, cpc.propertyName);
                                int MaxValQFIndex = 0;
                                while (tempProduct.getTotalValueForFeatureProperty(cpc.propertyName, cc.categoryName) <= cpc.num1)
                                {
                                    if (featureAdditionNoConstrainViolation(MaxValQF[MaxValQFIndex], tempProduct))
                                    {
                                        // add feature to the product
                                        tempProduct.addFeature(getAvailableFeature(MaxValQF[MaxValQFIndex].featureName));
                                        featuresAdded++;
                                    }
                                    MaxValQFIndex++;
                                    if (MaxValQFIndex >= MaxValQF.Count())
                                    {
                                        MessageBox.Show("Feature Selection Failed due to Max Value Constrain. Solution not possible.");
                                        button9.Enabled = true;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }


                    // then use greedy to add the rest of the features based on their added value
                    int numberOfCandidateFeatures = tempListOfavailableQF.Count();
                long c = 0;
                foreach (quantifiedFeature qf in tempListOfavailableQF)
                {
                    // the selection should stop, once the features with zero or less added value are reached
                    if (qf.addedValue <=0m) { break; }

                    // check if feature violete any constrain
                    if (featureAdditionNoConstrainViolation(qf,tempProduct)) {
                        // add feature to the product
                        tempProduct.addFeature(getAvailableFeature(qf.featureName));
                        featuresAdded++;
                    }
                    c++;
                    Application.DoEvents();
                    label9.Text = "Completed:" + c.ToString() + "/" + numberOfCandidateFeatures.ToString();
                }

            }else if (comboBox3.SelectedIndex == 2) // snail feature selection algorithm
            {
                
                //  MessageBox.Show("1"+tempProduct.ListOfFeatures.Count.ToString()+" "+tempListOfavailableQF.Count.ToString());
                tempProduct =quantifiedFeatureSelectionBasedOnExhaustiveSearch(tempProduct, tempListOfavailableQF);


            }
            string finishTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + ":" + DateTime.Now.Millisecond ;
            
            if (productConstrainViolation(tempProduct,false)==0)
            {
                loadedProduct.deleteAllFeatures();
                foreach (feature f in tempProduct.ListOfFeatures)
                {

                    loadedProduct.addFeature(f);
                }
                outputMessage = "Feature selection complete. ";
            }else
            {
                outputMessage = "Feature Selection Failed. "+ productAllConstrainViolation(tempProduct);
            }
            
            treeView2.Sorted = false;
            displayProductFeatures(0);
            comboBox5.SelectedIndex = 0;
            getProductValueANDNoOfFeatures();
            
                outputMessage = outputMessage + "Number of Candidates:" + tempListOfavailableQF.Count().ToString() + "," + tempProduct.ListOfFeatures.Count().ToString() + " features were added. Start Time:" + startTime + " Finish Time:" + finishTime;
            if (testMode)
            {
                outputMessage = outputMessage + FAFR.getReport();
                FAFR.reset();
            }
            MessageBox.Show(outputMessage);

            button9.Enabled = true;

        }

        // Iterative, using 'i' as bitmask to choose each combo members
        public product quantifiedFeatureSelectionBasedOnExhaustiveSearch(product inputProduct,List<quantifiedFeature> inputList)
        {
            ulong comboCount = (ulong)Math.Pow(2, inputList.Count) - 1;
            decimal bestProductAddedValue = 0m;
            product bestProduct = new product(inputProduct.name);
            product tmpProduct = new product(inputProduct.name);
            //MessageBox.Show("baaa");

            for (ulong i = 1; i < comboCount + 1; i++)
            {
               // MessageBox.Show("ba");

                // make each combo here
                List<quantifiedFeature> tempSelection = new List<quantifiedFeature>();
                decimal tmpSelectionAddedValue = 0m;
                for (int j = 0; j < inputList.Count; j++)
                {
                    if ((i >> j) % 2 != 0)
                    {
                        tempSelection.Add(inputList[j]);
                        tmpSelectionAddedValue = tmpSelectionAddedValue + inputList[j].addedValue;
                    }
                   // MessageBox.Show("aa");

                    if (tmpSelectionAddedValue> bestProductAddedValue)
                    {
                        tmpProduct.deleteAllFeatures();
                        
                        foreach (feature ff in inputProduct.ListOfFeatures)
                        {
                            tmpProduct.addFeature(ff);
                        }

                        foreach (quantifiedFeature q in tempSelection)
                        {
                            tmpProduct.addFeature(getAvailableFeature(q.featureName));
                        }
                      //  MessageBox.Show("aa3");
                        if (!productConstrainViolationWithReporting(tmpProduct)) { // if valid product
                            

                            bestProduct.deleteAllFeatures();
                            foreach (feature ff in tmpProduct.ListOfFeatures)
                            {
                                
                                bestProduct.addFeature(ff);
                            }
                            bestProductAddedValue = tmpSelectionAddedValue;
                         //   MessageBox.Show(tmpProduct.ListOfFeatures.Count.ToString()+" "+bestProductAddedValue.ToString());
                        }
                    }
                }

                Application.DoEvents();
                label9.Text = "Completed:" + i.ToString() + "/"+comboCount.ToString();
            }

            return bestProduct;
        }

        public int productConstrainViolation(product p,bool msg)
        {
            if (p!=null) {
               
                // 0: no violation
                // 1:max number of product features violation  
                // 2:min number of product features violation  
                // 3:max number of category features violation  
                // 4:min number of category features violation  
                // 5:Is the max number of occurencies of this feature valid?
                // 6:Propery Constrain violation
                // 7:Max product total property value violation
                // get the global and category constrains 
                Form3.categoryConstrain gc = null; // global constrain
                foreach (Form3.categoryConstrain c in listOfObjectives)
                {

                    if (c.categoryName.Equals("Global"))
                    {
                        gc = c;
                    }
                }
                /*
                 if (c.categoryName.Equals(qf.category))
                {
                    cc = c;
                } 
                 
                 */
                // do all the global checks
                //is the max number of features for this product valid 
                if (gc != null)
                {
                    if (gc.maxNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") > gc.maxNumberOfInstancesOfThisCategory) { if (msg) { MessageBox.Show("Max number of product features violation"); } return 1; } // 1:max number of product features violation
                    }
                    if (gc.minNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") <= gc.minNumberOfInstancesOfThisCategory) { if (msg) { MessageBox.Show("Min number of product features violation"); } return 2; } // 2:max number of product features violation
                    }
                }
                // do all the category and feature checks 
                foreach (feature f in p.ListOfFeatures)
                {
                    Form3.categoryConstrain cc = null; // category constrain

                    foreach (Form3.categoryConstrain k in listOfObjectives)
                    {

                        if (k.categoryName.Equals(f.category))
                        {
                            cc = k;
                        }
                    }
                    int multipleInstancesOfTheSameFeatureLOCAL = 1;
                    if (cc != null) 
                    {
                        multipleInstancesOfTheSameFeatureLOCAL=cc.multipleInstancesOfTheSameFeature;
                    }

                    if (p.numberOfOccurenciesOfFeatureInProduct(f.featureName) > multipleInstancesOfTheSameFeatureLOCAL) { if (msg) { MessageBox.Show("Max number of features occurencies ("+ p.numberOfOccurenciesOfFeatureInProduct(f.featureName).ToString() +") of "+f.featureName+" of category "+ f.category + " violation"); } return 5; }

                    if (cc != null)
                    {
                        //is the max number of features for this category valid 
                        if (cc.maxNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) > cc.maxNumberOfInstancesOfThisCategory) { if (msg) { MessageBox.Show("Max number of " + f.category + " features violation"); } return 3; }
                        }
                        //is the min number of features for this category valid 
                        if (cc.minNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) <= cc.minNumberOfInstancesOfThisCategory) { if (msg) { MessageBox.Show("Min number of " + f.category + " features violation"); } return 4; }
                        }

                        // is the max number of occurencies of this feature valid?
                    }

                    // check category property constrains:
                    foreach (Form3.categoryConstrain k in listOfObjectives) {

                        foreach (Form3.categoryPropertyConstrain cpc in k.listOfCategoryPropertiesObjectives)
                        {
                         //   MessageBox.Show(cpc.type.ToString());
                            if (cpc.type > 0)
                            {
                                //decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName) + Decimal.Parse(getAvailableFeature(f.featureName).getPropertyValue(cpc.propertyName));
                                
                                decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName,k.categoryName);
                             //   MessageBox.Show(cpc.num1.ToString() + "," + val.ToString());
                                if (cpc.type == 1)// less than
                                {
                                    if (val >= cpc.num1)
                                    {
                                        if (msg) { MessageBox.Show("Total property value constrain violation. "+val.ToString()+" (property value) not less than "+ cpc.num1.ToString()+ " (constraint value)"); }
                                        return 6;
                                    }
                                }
                                else if (cpc.type == 2)// more than
                                {
                                    if (val <= cpc.num1)
                                    {
                                        if (msg) { MessageBox.Show("Total property value constrain violation. " + val.ToString() + " (property value) not more than " + cpc.num1.ToString() + " (constraint value)"); }
                                        return 7;
                                    }
                                }
                                
                            }
                        }
                    }
                }
                if (msg) {
                    MessageBox.Show("No violation");
                } return 0; // no violation
            }
            else
            {
                if (msg) { MessageBox.Show("No product selected."); }
                return -1;
            }
        }

        public string productAllConstrainViolation(product p)
        {
            string output = "";
            if (p != null)
            {
                bool violation = false;
                // 0: no violation
                // 1:max number of product features violation  
                // 2:min number of product features violation  
                // 3:max number of category features violation  
                // 4:min number of category features violation  
                // 5:Is the max number of occurencies of this feature valid?
                // 6:Propery Constrain violation
                // 7:Max product total property value violation
                // get the global and category constrains 
                Form3.categoryConstrain gc = null; // global constrain
                foreach (Form3.categoryConstrain c in listOfObjectives)
                {

                    if (c.categoryName.Equals("Global"))
                    {
                        gc = c;
                    }
                }
                /*
                 if (c.categoryName.Equals(qf.category))
                {
                    cc = c;
                } 
                 
                 */
                // do all the global checks
                //is the max number of features for this product valid 
                if (gc != null)
                {
                    if (gc.maxNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") > gc.maxNumberOfInstancesOfThisCategory) { output+="Max number of product features violation."; violation = true; }  // 1:max number of product features violation
                    }
                    if (gc.minNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") <= gc.minNumberOfInstancesOfThisCategory) { output += "Min number of product features violation."; violation = true; } // 2:max number of product features violation
                    }
                }
                // do all the category and feature checks 
                foreach (feature f in p.ListOfFeatures)
                {
                    Form3.categoryConstrain cc = null; // category constrain

                    foreach (Form3.categoryConstrain k in listOfObjectives)
                    {

                        if (k.categoryName.Equals(f.category))
                        {
                            cc = k;
                        }
                    }
                    int multipleInstancesOfTheSameFeatureLOCAL = 1;
                    if (cc != null)
                    {
                        multipleInstancesOfTheSameFeatureLOCAL = cc.multipleInstancesOfTheSameFeature;
                    }

                    if (p.numberOfOccurenciesOfFeatureInProduct(f.featureName) > multipleInstancesOfTheSameFeatureLOCAL) { output += "Max number of features occurencies (" + p.numberOfOccurenciesOfFeatureInProduct(f.featureName).ToString() + ") of " + f.featureName + " of category " + f.category + " violation."; violation = true; } 

                    if (cc != null)
                    {
                        //is the max number of features for this category valid 
                        if (cc.maxNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) > cc.maxNumberOfInstancesOfThisCategory) { output += "Max number of " + f.category + " features violation."; violation = true; }  
                        }
                        //is the min number of features for this category valid 
                        if (cc.minNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) <= cc.minNumberOfInstancesOfThisCategory) { output += "Min number of " + f.category + " features violation."; violation = true; } 
                        }

                        // is the max number of occurencies of this feature valid?
                    }

                    // check category property constrains:
                    foreach (Form3.categoryConstrain k in listOfObjectives)
                    {

                        foreach (Form3.categoryPropertyConstrain cpc in k.listOfCategoryPropertiesObjectives)
                        {
                            //   MessageBox.Show(cpc.type.ToString());
                            if (cpc.type > 0)
                            {
                                //decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName) + Decimal.Parse(getAvailableFeature(f.featureName).getPropertyValue(cpc.propertyName));

                                decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName, k.categoryName);
                                //   MessageBox.Show(cpc.num1.ToString() + "," + val.ToString());
                                if (cpc.type == 1)// less than
                                {
                                    if (val >= cpc.num1)
                                    {
                                        output += "Total property value constrain violation. " + val.ToString() + " (property value) not less than " + cpc.num1.ToString() + " (constraint value)."; violation = true;

                                    }
                                }
                                else if (cpc.type == 2)// more than
                                {
                                    if (val <= cpc.num1)
                                    {
                                        output += "Total property value constrain violation. " + val.ToString() + " (property value) not more than " + cpc.num1.ToString() + " (constraint value)."; violation = true;

                                    }
                                }

                            }
                        }
                    }
                }
                if (violation==false) {
                    return "No violation";
                }
               
            }
            else
            {
                 MessageBox.Show("No product selected."); 
                return "";
            }
            return output;
        }


        public bool productConstrainViolationWithReporting(product p)
        {
            bool violation = false;
         
                
                // 0: no violation
                // 1:max number of product features violation  
                // 2:min number of product features violation  
                // 3:max number of category features violation  
                // 4:min number of category features violation  
                // 5:Is the max number of occurencies of this feature valid?
                // 6:Propery Constrain violation
                // 7:Max product total property value violation
                // get the global and category constrains 
                Form3.categoryConstrain gc = null; // global constrain
                foreach (Form3.categoryConstrain c in listOfObjectives)
                {

                    if (c.categoryName.Equals("Global"))
                    {
                        gc = c;
                    }
                }
                /*
                 if (c.categoryName.Equals(qf.category))
                {
                    cc = c;
                } 
                 
                 */
                // do all the global checks
                //is the max number of features for this product valid 
                if (gc != null)
                {
                    if (gc.maxNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") > gc.maxNumberOfInstancesOfThisCategory) { FAFR.report(2); violation = true; }  // 1:max number of product features violation
                    }
                    if (gc.minNumberOfInstancesOfThisCategory > -1)
                    {
                        if (p.numberOfFeaturesUnderCategory("Global") <= gc.minNumberOfInstancesOfThisCategory) { FAFR.report(6); violation = true; } // 2:max number of product features violation
                    }
                }
                // do all the category and feature checks 
                foreach (feature f in p.ListOfFeatures)
                {
                    Form3.categoryConstrain cc = null; // category constrain

                    foreach (Form3.categoryConstrain k in listOfObjectives)
                    {

                        if (k.categoryName.Equals(f.category))
                        {
                            cc = k;
                        }
                    }
                    int multipleInstancesOfTheSameFeatureLOCAL = 1;
                    if (cc != null)
                    {
                        multipleInstancesOfTheSameFeatureLOCAL = cc.multipleInstancesOfTheSameFeature;
                    }

                    if (p.numberOfOccurenciesOfFeatureInProduct(f.featureName) > multipleInstancesOfTheSameFeatureLOCAL) { FAFR.report(3); violation = true; }

                    if (cc != null)
                    {
                        //is the max number of features for this category valid 
                        if (cc.maxNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) > cc.maxNumberOfInstancesOfThisCategory) { FAFR.report(4); violation = true; }
                        }
                        //is the min number of features for this category valid 
                        if (cc.minNumberOfInstancesOfThisCategory > -1)
                        {
                            if (p.numberOfFeaturesUnderCategory(f.category) <= cc.minNumberOfInstancesOfThisCategory) { FAFR.report(7); violation = true; }
                        }

                        // is the max number of occurencies of this feature valid?
                    }

                    // check category property constrains:
                    foreach (Form3.categoryConstrain k in listOfObjectives)
                    {

                        foreach (Form3.categoryPropertyConstrain cpc in k.listOfCategoryPropertiesObjectives)
                        {
                            //   MessageBox.Show(cpc.type.ToString());
                            if (cpc.type > 0)
                            {
                                //decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName) + Decimal.Parse(getAvailableFeature(f.featureName).getPropertyValue(cpc.propertyName));

                                decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName, k.categoryName);
                                //   MessageBox.Show(cpc.num1.ToString() + "," + val.ToString());
                                if (cpc.type == 1)// less than
                                {
                                    if (val >= cpc.num1)
                                    {
                                    FAFR.report(1); violation = true;

                                    }
                                }
                                else if (cpc.type == 2)// more than
                                {
                                    if (val <= cpc.num1)
                                    {
                                    FAFR.report(5); violation = true;
                                }
                                }

                            }
                        }
                    }
                }
             

            
           
            return violation;
        }


        public class featureAdditionFailureReporting
        {
            public void report(int FCase)
            {
                if (FCase == 0)
                {
                    numberOfFailedFeatures++;
                }else if (FCase == 1)
                {
                    lessThan++;
                }
                else if (FCase == 2)
                {
                    maxNumberOfProductFeatures++;
                }
                else if (FCase == 3)
                {
                    maxNumberOfOccurencies++;
                }
                else if (FCase == 4)
                {
                    maxNumberOfCategoryFeatures++;
                }
                else if (FCase == 5)
                {
                    moreThan++;
                }
                else if (FCase == 6)
                {
                    minNumberOfProductFeatures++;
                }
                else if (FCase == 7)
                {
                    minNumberOfCategoryFeatures++;
                }

            }
            public void reset()
            {

                numberOfFailedFeatures = 0;
           lessThan = 0;
            maxNumberOfProductFeatures = 0;
            maxNumberOfOccurencies = 0;
            maxNumberOfCategoryFeatures = 0;
            moreThan = 0;
             minNumberOfProductFeatures = 0;
            minNumberOfCategoryFeatures = 0;


        }
            private int numberOfFailedFeatures = 0;
            private int lessThan = 0;
            private int maxNumberOfProductFeatures = 0;
            private int maxNumberOfOccurencies = 0;
            private int maxNumberOfCategoryFeatures = 0;
            private int moreThan = 0;
            private int minNumberOfProductFeatures = 0;
            private int minNumberOfCategoryFeatures = 0;



            public string getReport()
            {
                string output = "Number Of features attempted but not added:"+numberOfFailedFeatures.ToString() + ", Less than violations:" + lessThan.ToString()+", More than violations:" + moreThan.ToString()+ ", Min number of product features violation:"+ minNumberOfProductFeatures.ToString() + ", Max number of product features violation:" + maxNumberOfProductFeatures.ToString() + ", Mix number Of category features violation:" + minNumberOfCategoryFeatures.ToString() + ", Max number Of category features violation:"+ maxNumberOfCategoryFeatures.ToString()+ " & Max number Of occurencies violation:"+ maxNumberOfOccurencies.ToString();


                return output;

            }


        }

        featureAdditionFailureReporting FAFR = new featureAdditionFailureReporting();
        public bool featureAdditionNoConstrainViolation(quantifiedFeature qf,product p)
        {
            bool result=true;
            // get the global and category constrains 
            Form3.categoryConstrain cc = null; // category constrain
            Form3.categoryConstrain gc = null; // global constrain
            
            foreach (Form3.categoryConstrain c in listOfObjectives)
            {
                if (c.categoryName.Equals(qf.category))
                {
                    cc = c;
                }
                if (c.categoryName.Equals("Global"))
                {
                    gc = c;
                }
            }
            //MessageBox.Show("aaa");
            // check category property constrains:
            foreach (Form3.categoryConstrain c in listOfObjectives)
            {

                foreach (Form3.categoryPropertyConstrain cpc in c.listOfCategoryPropertiesObjectives)
                {
                    if (cpc.type > 0)
                    {
                        decimal val = p.getTotalValueForFeatureProperty(cpc.propertyName, c.categoryName) + getAvailableFeature(qf.featureName).getNumericPropertyValue(cpc.propertyName);
                        if (cpc.type == 1)// less than
                        {
                            if (val >= cpc.num1)
                            {
                                result = false;
                                FAFR.report(1);
                            }
                        }
                      /*  else if (cpc.type == 2)// more than
                        {
                            if (val <= cpc.num1)
                            {
                                return false;
                            }
                        }
                        */
                    }
                }
            }
            // do all the checks here

            // if the addedvalue is less or equal to zero
            if (qf.addedValue<=0m)
            {
                return false;
            }

            //is the max number of features for this product valid 
            if (gc!=null) {
                if (gc.maxNumberOfInstancesOfThisCategory > -1)
                {
                    if (p.numberOfFeaturesUnderCategory("Global") >= gc.maxNumberOfInstancesOfThisCategory)
                    {
                        result = false;
                        FAFR.report(2);
                    }
                }
            }
            int multipleInstancesOfTheSameFeatureLOCAL = 1;
            if (cc!=null)
            {
                multipleInstancesOfTheSameFeatureLOCAL = cc.multipleInstancesOfTheSameFeature;
            }
            // is the max number of occurencies of this feature valid?
            if (p.numberOfOccurenciesOfFeatureInProduct(qf.featureName) >= multipleInstancesOfTheSameFeatureLOCAL)
            {
                result = false;
                FAFR.report(3);
            }


            if (cc!=null) {
                //is the max number of features for this category valid 
                if (cc.maxNumberOfInstancesOfThisCategory > -1) {
                    if (p.numberOfFeaturesUnderCategory(qf.category) >= cc.maxNumberOfInstancesOfThisCategory)
                    {
                        result = false;
                        FAFR.report(4);
                    }
                }
               



            }
            if (!result)
            {
                FAFR.report(0); // increase the number of failed features
            }
          
            return result;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        bool v3s = false;
        private void button22_Click(object sender, EventArgs e)
        {
            if (!v3s)
            {
                button22.Text = "U";
                treeView3.Sort();
                v3s = true;
            }
            else
            {
                button22.Text = "A";
                treeView3.Sorted = false;
                v3s = false;
            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            displayQuantifiedFeatures(comboBox6.SelectedIndex);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            int ni = 0;
            if (comboBox6.SelectedIndex == 1) { ni = 1; } else { ni = 0; }

            try
            {
                if ((treeView3.SelectedNode.Level == ni) && (comboBox2.SelectedIndex > -1))
                {
                    loadedProduct.ListOfFeatures.Add(listOfAvailableFeatures[getFeatureIndex(treeView3.SelectedNode.Text, listOfAvailableFeatures)]);
                    displayProductFeatures(comboBox5.SelectedIndex);
                    MessageBox.Show("Feature " + treeView3.SelectedNode.Text + " has been added to product " + comboBox2.Text);
                }
                else
                {

                    MessageBox.Show("Please select a feature. Not a property. Also ensure that you have selected a product.");
                }

            }
            catch { MessageBox.Show("No node selected"); }
            getProductValueANDNoOfFeatures();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            button24.Enabled = false;
            string startTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + ":" + DateTime.Now.Millisecond;
            quantifyAvailableFeatures(true);
            getProductValueANDNoOfFeatures();
           
                string finishTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + ":" + DateTime.Now.Millisecond;
                MessageBox.Show("Quantification of features has been completed." + "Start Time:" + startTime + ". Finish Time:" + finishTime);
            button24.Enabled = true;

        }
        public Form3.categoryConstrain getObjective(string catName)
        {
            foreach (Form3.categoryConstrain cc in listOfObjectives)
            {
                if (cc.categoryName.Equals(catName))
                {
                    return cc;
                }

            }
           

            return null;
        }
        public decimal getMaxPropertyValue(string pName, string category)
        {
            decimal val = -9999999;
            foreach (feature f in listOfAvailableFeatures)
            {
                if (f.category.Equals(category)||category.Equals("Global")){ // if feature under target category
                 if (f.getNumericPropertyValue(pName)>val) { val = f.getNumericPropertyValue(pName);   }
                }

            }

            return val;

        }
        public decimal getMinPropertyValue(string pName, string category)
        {
            
            decimal val = 9999999;
            foreach (feature f in listOfAvailableFeatures)
            {
                if (f.category.Equals(category) || category.Equals("Global"))
                { // if feature under target category
                    if (f.getNumericPropertyValue(pName) < val) { val = f.getNumericPropertyValue(pName); }
                }

            }
            return val;
        }
        public decimal percentageOfProximity(decimal farawayVal,decimal targetVal,decimal val,char better, char direction)
        {
            decimal r = 0.00m;
            decimal range = Math.Abs(farawayVal) + Math.Abs(targetVal);
            if (range == 0) { range = 0.00000001m; }
            if (direction == 'f')
            {
                if (better == 'h') // higher is better
                {
                    r = ((decimal)(val + Math.Abs(farawayVal)) * 100m) / range;
                }
                else if (better == 'l')// lower is better
                {
                    r = ((decimal)(Math.Abs(targetVal)) - Math.Abs(val) * 100m) / range;
                    r = 100m + r;
                    //MessageBox.Show("t:"+targetVal+"val:"+val+"range:"+range+"r:"+r);
                }
            }else if (direction=='r')
            {
                if (better == 'h') // higher is better
                {
                    //in this case, faraway ia the max and target is the min
                    r = 100 - ((Math.Abs(farawayVal) - Math.Abs(val)) / (Math.Abs(farawayVal) - Math.Abs(targetVal)))*100m;
                    //((decimal)(val + Math.Abs(farawayVal)) * 100m) / range;
                    //MessageBox.Show(r.ToString());
                }
                else if (better == 'l')// lower is better
                {
                    r =  ((Math.Abs(farawayVal) - Math.Abs(val)) / (Math.Abs(farawayVal) - Math.Abs(targetVal))) * 100m;                
                    //MessageBox.Show("t:"+targetVal+"val:"+val+"range:"+range+"r:"+r);
                }

            }
            if (r == 0) r = r + 0.000001m;
            return r;
   
        }
      
    public string[] returnListOfString(string s,char target)
        {
            string[] subStrings = s.Split(target);
                       
            return subStrings;
        }
        public int numberOfSubstringInString(string s,char target)
        {
          
            
            string[] subStrings = s.Split(target);
            

            return subStrings.Length;

            
        }

        public quantifiedFeature quantifyFeature(feature f )
        {
            quantifiedFeature tempQF = null;
            // first quantify all feature properties based on Global objectives
            Form3.categoryConstrain cc = getObjective("Global");
            bool getNumberOfOccurenciesOfTheFeatureInOtherProducts = false;
            if (cc != null)
            {
                getNumberOfOccurenciesOfTheFeatureInOtherProducts = cc.favourFeaturesExistInOtherProducts;
                 foreach (Form3.objectives p in cc.listOfFeaturePropertiesObjectives)
                  {
                    // if the feature also has this property
                    if (f.getPropertyValue(p.propertyName).Length > 0)
                    {

                        if (tempQF == null)
                        {
                            tempQF = new quantifiedFeature(f.featureName, f.category);
                        }
                        quantifiedProperty qp = new quantifiedProperty();
                        qp.propertyName = p.propertyName;

                        try
                        {
                            // get quantified value
                            if (p.type == 1) // if string exist in txt (analog)
                            {

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    //    MessageBox.Show("FName:"+f.featureName+" PName:"+p.propertyName+" PValue:"+ f.getPropertyValue(p.propertyName) + " total:"+numberOfSubstring.ToString() + " found:" + numberOfSubstringsMatched.ToString());
                                    qp.value = ((decimal)numberOfSubstringsMatched * 100m) / (decimal)numberOfSubstring;
                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 2) // if string DOES NOT exist in txt (analog)
                            {

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100) / (decimal)numberOfSubstring;

                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 3) // include and exclude string (analog)
                            {
                                decimal score1 = 0;
                                decimal score2 = 0;
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = (decimal)(numberOfSubstringsMatched * 100) / (decimal)numberOfSubstring;

                                numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt2, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score2 = (((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100m) / (decimal)numberOfSubstring);
                                qp.value = (score1 + score2) / 2m;



                            }
                            else if (p.type == 4) // Must Include
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstring - numberOfSubstringsMatched == 0)
                                    {
                                        qp.value = 100;
                                    }
                                    else
                                    {
                                        qp.value = 0;
                                    }


                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 5) // Must Not Include in txt
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstring - numberOfSubstringsMatched == 0)
                                    {
                                        qp.value = 0;
                                    }
                                    else
                                    {
                                        qp.value = 100;
                                    }


                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }

                            else if (p.type == 7) // Must Include AND Exclude
                            {
                                decimal score1 = 0;

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = numberOfSubstring - numberOfSubstringsMatched;
                                if (score1 == 0)
                                {
                                    numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt2, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100) / (decimal)numberOfSubstring;


                                }
                                else
                                {
                                    qp.value = 0;

                                }




                            }

                            else if (p.type == 6) // Must Include AND Must Exclude
                            {
                                decimal score1 = 0;

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = numberOfSubstring - numberOfSubstringsMatched;
                                if (score1 == 0)
                                {
                                    numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt2, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstringsMatched > 0) { qp.value = 0; }
                                    else
                                    {
                                        qp.value = 100;
                                    }


                                }
                                else
                                {
                                    qp.value = 0;

                                }




                            }
                            else if (p.type == 8) // Include AND Must Exclude
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt2, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                if (numberOfSubstringsMatched > 0) { qp.value = 0; }
                                else
                                {

                                    numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)numberOfSubstringsMatched * 100m) / (decimal)numberOfSubstring;





                                }

                            }
                            else if (p.type == 9) // if equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 10) // if aproximenty equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {

                                    decimal val = ((Math.Abs(Math.Abs(p.numeric1) - f.getNumericPropertyValue(p.propertyName))) / Math.Abs(p.numeric1)) * 100m;

                                    decimal valMax = ((getMaxPropertyValue(p.propertyName, f.category) - Math.Abs(p.numeric1)) / Math.Abs(p.numeric1)) * 100m;
                                    decimal valMin = ((Math.Abs(p.numeric1) - getMinPropertyValue(p.propertyName, f.category)) / Math.Abs(p.numeric1)) * 100m;
                                    qp.value = ((Math.Abs(val - valMin)) / valMax);


                                }

                            }
                            else if (p.type == 11) // if not equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    qp.value = 100;
                                }

                            }
                            else if (p.type == 12) // upto (Higher is better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'f');
                                }

                            }
                            else if (p.type == 13) // upto (lower is better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    // if (p.numeric1 - getMinPropertyValue(p.propertyName, cc.categoryName) == 0) { MessageBox.Show("bbb"); }
                                    //qp.value = 100 * ((p.numeric1 - Decimal.Parse(f.getPropertyValue(p.propertyName))/(p.numeric1 + getMinPropertyValue(p.propertyName, cc.categoryName))));
                                     qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'f');
                                     if (qp.value > 100) qp.value = 100;
                                }

                            }
                            else if (p.type == 14) // more than)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 15) // less than)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) < p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 16) // between)
                            {

                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName) < p.numeric2))
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 17) // between higher better)
                            {
                                // if bettween calc else zero
                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName)) < p.numeric2)
                                {

                                    if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                    {
                                        qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'r');

                                    }
                                    else if (f.getNumericPropertyValue(p.propertyName) < p.numeric2)
                                    {
                                        qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'f');

                                    }
                                    else // if equal 
                                    {
                                        qp.value = 0;
                                    }


                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 18) // between lower better)
                            {
                                // if bettween calc else zero
                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName) < p.numeric2))
                                {

                                    qp.value = 100 * ((p.numeric2 - f.getNumericPropertyValue(p.propertyName))/ p.numeric1);
                                    // / (p.numeric2 - p.numeric1)) * 100;

                                   // qp.value = 100 - ((Decimal.Parse(f.getPropertyValue(p.propertyName)) - p.numeric1)/(p.numeric2 - p.numeric1)) * 100; 

/*
                                    if (Decimal.Parse(f.getPropertyValue(p.propertyName)) > p.numeric1)
                                    {
                                        qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, Decimal.Parse(f.getPropertyValue(p.propertyName)), 'l', 'r');

                                    }
                                    else if (Decimal.Parse(f.getPropertyValue(p.propertyName)) < p.numeric2)
                                    {
                                        qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric2, Decimal.Parse(f.getPropertyValue(p.propertyName)), 'l', 'f');

                                    }
                                    else // if equal 
                                    {
                                        qp.value = 0;
                                    }

    */
                                }
                                else
                                {
                                    qp.value = 0;
                                }


                            }
                            else if (p.type == 19) // equal & above higher better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) >= p.numeric1)
                                {
                                    qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'r');

                                }
                                else
                                {
                                    qp.value = 0;
                                }
                            }
                            else if (p.type == 20) // equal & above lower better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) >= p.numeric1)
                                {
                                    qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'r');

                                }
                                else
                                {
                                    qp.value = 0;
                                }
                            }
                            // end of get quantified value
                            tempQF.addQuantifiedProperty(qp);
                        }
                        catch  { qp.value = -2m; tempQF.listOfQuantifiedProperties.Add(qp); MessageBox.Show("An exception was encountered while quantifying property:"+p.propertyName+" of feature:"+f.featureName); }
                    }
                    
                }
            }//end of  quantification based on global objectives

            // second, quantify the feature based on its category objectives (overwrite)
            cc = null;
            cc = getObjective(f.category);

            if (cc != null)
            {
                foreach (Form3.objectives p in cc.listOfFeaturePropertiesObjectives)
                {
                    // if the feature also has this property
                    if (f.getPropertyValue(p.propertyName).Length > 0)
                    {

                        if (tempQF == null)
                        {
                            tempQF = new quantifiedFeature(f.featureName, f.category);
                        }
                        quantifiedProperty qp = new quantifiedProperty();
                        qp.propertyName = p.propertyName;

                        try
                        {
                            // get quantified value
                            if (p.type == 1) // if string exist in txt (analog)
                            {

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    //    MessageBox.Show("FName:"+f.featureName+" PName:"+p.propertyName+" PValue:"+ f.getPropertyValue(p.propertyName) + " total:"+numberOfSubstring.ToString() + " found:" + numberOfSubstringsMatched.ToString());
                                    qp.value = ((decimal)numberOfSubstringsMatched * 100m) / (decimal)numberOfSubstring;
                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 2) // if string DOES NOT exist in txt (analog)
                            {

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100) / (decimal)numberOfSubstring;

                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 3) // include and exclude string (analog)
                            {
                                decimal score1 = 0;
                                decimal score2 = 0;
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = (decimal)(numberOfSubstringsMatched * 100) / (decimal)numberOfSubstring;

                                numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt2, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score2 = (((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100m) / (decimal)numberOfSubstring);
                                qp.value = (score1 + score2) / 2m;



                            }
                            else if (p.type == 4) // Must Include
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstring - numberOfSubstringsMatched == 0)
                                    {
                                        qp.value = 100;
                                    }
                                    else
                                    {
                                        qp.value = 0;
                                    }


                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }
                            else if (p.type == 5) // Must Not Include in txt
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;
                                if (numberOfSubstring > 0)
                                {
                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstring - numberOfSubstringsMatched == 0)
                                    {
                                        qp.value = 0;
                                    }
                                    else
                                    {
                                        qp.value = 100;
                                    }


                                }
                                else
                                {

                                    qp.value = -1;
                                }

                            }

                            else if (p.type == 7) // Must Include AND Exclude
                            {
                                decimal score1 = 0;

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = numberOfSubstring - numberOfSubstringsMatched;
                                if (score1 == 0)
                                {
                                    numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt2, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)(numberOfSubstring - numberOfSubstringsMatched) * 100) / (decimal)numberOfSubstring;


                                }
                                else
                                {
                                    qp.value = 0;

                                }




                            }

                            else if (p.type == 6) // Must Include AND Must Exclude
                            {
                                decimal score1 = 0;

                                int numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt1, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                score1 = numberOfSubstring - numberOfSubstringsMatched;
                                if (score1 == 0)
                                {
                                    numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt2, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    if (numberOfSubstringsMatched > 0) { qp.value = 0; }
                                    else
                                    {
                                        qp.value = 100;
                                    }


                                }
                                else
                                {
                                    qp.value = 0;

                                }




                            }
                            else if (p.type == 8) // Include AND Must Exclude
                            {
                                int numberOfSubstring = numberOfSubstringInString(p.txt2, '+');
                                int numberOfSubstringsMatched = 0;

                                foreach (string s in returnListOfString(p.txt2, '+'))
                                {
                                    if (f.getPropertyValue(p.propertyName).Contains(s))
                                    {
                                        numberOfSubstringsMatched++;
                                    }

                                }
                                if (numberOfSubstringsMatched > 0) { qp.value = 0; }
                                else
                                {

                                    numberOfSubstring = numberOfSubstringInString(p.txt1, '+');
                                    numberOfSubstringsMatched = 0;

                                    foreach (string s in returnListOfString(p.txt1, '+'))
                                    {
                                        if (f.getPropertyValue(p.propertyName).Contains(s))
                                        {
                                            numberOfSubstringsMatched++;
                                        }

                                    }
                                    qp.value = ((decimal)numberOfSubstringsMatched * 100m) / (decimal)numberOfSubstring;





                                }

                            }
                            else if (p.type == 9) // if equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 10) // if aproximenty equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {

                                    decimal val = ((Math.Abs(Math.Abs(p.numeric1) - f.getNumericPropertyValue(p.propertyName))) / Math.Abs(p.numeric1)) * 100m;

                                    decimal valMax = ((getMaxPropertyValue(p.propertyName, f.category) - Math.Abs(p.numeric1)) / Math.Abs(p.numeric1)) * 100m;
                                    decimal valMin = ((Math.Abs(p.numeric1) - getMinPropertyValue(p.propertyName, f.category)) / Math.Abs(p.numeric1)) * 100m;
                                    qp.value = ((Math.Abs(val - valMin)) / valMax);


                                }

                            }
                            else if (p.type == 11) // if not equal to
                            {
                                if (f.getNumericPropertyValue(p.propertyName) == p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    qp.value = 100;
                                }

                            }
                            else if (p.type == 12) // upto (Higher is better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'f');
                                }

                            }
                            else if (p.type == 13) // upto (lower is better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 0;
                                }
                                else
                                {
                                    qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'f');
                                }

                            }
                            else if (p.type == 14) // more than)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 15) // less than)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) < p.numeric1)
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 16) // between)
                            {

                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName) < p.numeric2))
                                {
                                    qp.value = 100;
                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 17) // between higher better)
                            {
                                // if bettween calc else zero
                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName) < p.numeric2))
                                {

                                    if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                    {
                                        qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'r');

                                    }
                                    else if (f.getNumericPropertyValue(p.propertyName) < p.numeric2)
                                    {
                                        qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'f');

                                    }
                                    else // if equal 
                                    {
                                        qp.value = 0;
                                    }


                                }
                                else
                                {
                                    qp.value = 0;
                                }

                            }
                            else if (p.type == 18) // between lower better)
                            {
                                // if bettween calc else zero
                                if ((f.getNumericPropertyValue(p.propertyName) > p.numeric1) && (f.getNumericPropertyValue(p.propertyName) < p.numeric2))
                                {

                                    if (f.getNumericPropertyValue(p.propertyName) > p.numeric1)
                                    {
                                        qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'r');

                                    }
                                    else if (f.getNumericPropertyValue(p.propertyName) < p.numeric2)
                                    {
                                        qp.value = percentageOfProximity(getMinPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'f');

                                    }
                                    else // if equal 
                                    {
                                        qp.value = 0;
                                    }


                                }
                                else
                                {
                                    qp.value = 0;
                                }


                            }
                            else if (p.type == 19) // equal & above higher better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) >= p.numeric1)
                                {
                                    qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'h', 'r');

                                }
                                else
                                {
                                    qp.value = 0;
                                }
                            }
                            else if (p.type == 20) // equal & above lower better)
                            {

                                if (f.getNumericPropertyValue(p.propertyName) >= p.numeric1)
                                {
                                    qp.value = percentageOfProximity(getMaxPropertyValue(p.propertyName, cc.categoryName), p.numeric1, f.getNumericPropertyValue(p.propertyName), 'l', 'r');

                                }
                                else
                                {
                                    qp.value = 0;
                                }
                            }
                            // end of get quantified value
                            tempQF.addQuantifiedProperty(qp);
                        }
                        catch { qp.value = 0; tempQF.listOfQuantifiedProperties.Add(qp); MessageBox.Show("An exception was encountered while quantifying property:" + p.propertyName + " of feature:" + f.featureName); }
                    }

                }

            }

            // end of quantification

            // calculate number of occurencies at that certain point of time
            tempQF.occurenciesOfFeatureExistInOtherProductsOfTheSPL = -1;
            if (tempQF != null)
                if (getNumberOfOccurenciesOfTheFeatureInOtherProducts)
                {
                    tempQF.occurenciesOfFeatureExistInOtherProductsOfTheSPL = featureExistInOtherProductsOfTheSPL(tempQF.featureName);
                }
            return tempQF;
        }

        public void quantifyAvailableFeatures(bool msg)
        {
            
            listOfAvailableQuantifiedFeatures.Clear();
            // chech if there are objectives
            
            if (listOfObjectives.Count()>0)
            {
                bool featurePropertyConstrains = false;
                foreach (Form3.categoryConstrain cc in listOfObjectives)
                {
                    if (cc.listOfFeaturePropertiesObjectives.Count()>0)
                    {
                        featurePropertyConstrains = true;
                    }
                }
                
                if (featurePropertyConstrains==false)
                {
                    MessageBox.Show("No feature level property constrains were selected");
                    return;
                }

                int numberOfFeaturesToBeQualified = listOfAvailableFeatures.Count();
                int featuresDone = 0;
                foreach (feature f in listOfAvailableFeatures)
                {
                    //  quantify all features 
                    
                    quantifiedFeature qf = quantifyFeature(f);
                    if (qf != null)
                    {
                        qf.setAddedValue();
                        listOfAvailableQuantifiedFeatures.Add(qf);

                    }
                    featuresDone++;
                    Application.DoEvents();
                    label9.Text = "Completed:" + featuresDone.ToString() + "/" + numberOfFeaturesToBeQualified.ToString();

                }
            
              
                displayQuantifiedFeatures(0);
            }
            else
            {

                MessageBox.Show("No Objectives. Please set some objectives first.");
            }
            sortAvailableQuantifiedFeaturesByAddedValue();
        }
        public void getProductValueANDNoOfFeatures()
        {

            label8.Text = "Number Of Features:" + loadedProduct.ListOfFeatures.Count().ToString();
            decimal productAddedValue = 0m;
            if (listOfAvailableQuantifiedFeatures.Count()>0)
            {
                foreach (feature f in loadedProduct.ListOfFeatures)
                {
                    productAddedValue = productAddedValue + getFeatureAddedValue(f.featureName);
                }
                label7.Text = "Product Added Value:" + productAddedValue.ToString();
            }
            else
            {
                label7.Text = "Product Added Value: N/A";
            }
            

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The orignal version of this tool has been developed by Fazal Qudus Khan, George Tsarmirsis, Seyed Mohamed Buhari & Shahrulniza Musa @2019.");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void reloadAvailableFeaturesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView1.Sorted = false;
            loadAvailableFeatures();
            displayAvailableFeatures(0);
            comboBox4.SelectedIndex = 0;
        }

        private void reloadProductFeaturesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView2.Sorted = false;
            loadProduct();
            displayProductFeatures(0);
            comboBox5.SelectedIndex = 0;
            getProductValueANDNoOfFeatures();
        }

        private void saveProductFeaturesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveProduct();
        }

        private void importFeaturesFromXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listOfAvailableFeatures.Clear();
            treeView1.Nodes.Clear();
            listOfAvailableCategories.Clear();
            treeView1.Refresh();

            importAvailableFeatures();
            MessageBox.Show(listOfAvailableFeatures.Count().ToString() + " features loaded.");
        }

        private void exportQuantifiedFeaturesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            exportQuantifiedFeatures();
        }
        public void generateReport()
        {
            if (comboBox2.SelectedIndex>-1)
            {
                string productFileName = "./" + comboBox2.Text + "_report.txt";
                using (StreamWriter outputFile = new StreamWriter(@productFileName))
                {
                    outputFile.WriteLine("Product Name:"+ comboBox2.Text);
                    outputFile.WriteLine("SPL:" + comboBox1.Text);
                    outputFile.WriteLine("Date:" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                    outputFile.WriteLine(label7.Text);
                    outputFile.WriteLine(label8.Text);
                    foreach (Form3.categoryConstrain cc in listOfObjectives)
                    {
                        foreach (Form3.categoryPropertyConstrain cpc in cc.listOfCategoryPropertiesObjectives)
                        {
                            outputFile.WriteLine("Total value for property "+cpc.propertyName+":"+loadedProduct.getTotalValueForFeatureProperty(cpc.propertyName,"Global").ToString());

                        }
                    }
                    outputFile.WriteLine("Objectives:");
                    outputFile.WriteLine(displayAllObjectives(listOfObjectives));
                    outputFile.WriteLine("");
                    outputFile.WriteLine("List of selected features by category:");
                   
                        //**
                     
                       
                                               
                        foreach (string s in productCategories)
                            {
                            outputFile.WriteLine("Category:"+s);
                           
                                foreach (feature f in loadedProduct.ListOfFeatures)
                                {
                                    if (f.category.Equals(s))
                            {

                                outputFile.WriteLine("Feature:" + f.featureName);
                                quantifiedFeature tmpQF = getQuantifiedFeature(f.featureName);
                                outputFile.WriteLine("AddedValue:"+ tmpQF.addedValue.ToString());
                                outputFile.WriteLine("Occurencies in other products:" + tmpQF.occurenciesOfFeatureExistInOtherProductsOfTheSPL.ToString());
                                
                                
                                        foreach (featureProperty p in f.ListOfProperties)
                                        {
                                    outputFile.WriteLine(p.propertyName+":");
                                    decimal av = tmpQF.getQuantifiedPropertyValue(p.propertyName);
                                    if (av>-2)
                                    {
                                        outputFile.WriteLine("AddedValue:" + av.ToString());
                                    } else
                                    {
                                        outputFile.WriteLine("AddedValue:NA");
                                    }
                                    
                                    outputFile.WriteLine("Property Value:"+p.propertyValue);
                                }
                                        
                                    }

                                }
                               
                            }


                            //**
                

            }
                MessageBox.Show("Report generated in " + comboBox2.Text + "_report.txt");
            }
            else
            {
                MessageBox.Show("No product selected");
            }
        }
        public decimal getFeatureAddedValue(string featureName)
        {
            foreach (quantifiedFeature qf in listOfAvailableQuantifiedFeatures)
            {
                if (qf.featureName.Equals(featureName))
                {
                    return qf.addedValue;
                }
            }
            return -1m;
        }
        public quantifiedFeature getQuantifiedFeature(string featureName)
        {
            foreach (quantifiedFeature qf in listOfAvailableQuantifiedFeatures)
            {
                if (qf.featureName.Equals(featureName))
                {
                    return qf;
                }
            }
            return null;
        }
        private void generateReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            generateReport();
        }
        public int featureExistInOtherProductsOfTheSPL(string featureName)
        {
            int numberOfInstancesOfTheFeature = 0;
            foreach (product p in ListOfSPLs[SPLComboboxIndex].ListOfProducts)
            {
                p.loadProductFeaturesFromFile();
                if (p.getFeature(featureName) != null) { numberOfInstancesOfTheFeature++; }
                p.ListOfFeatures.Clear(); // for reducing the space in memory
            }

            return numberOfInstancesOfTheFeature;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            treeView2.Sorted = false;
            loadedProduct.ListOfFeatures.Clear();
            displayProductFeatures(0);
            comboBox5.SelectedIndex = 0;
            getProductValueANDNoOfFeatures();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex>-1) {
                MessageBox.Show(productAllConstrainViolation(loadedProduct));
            }
            else
            {
                MessageBox.Show("No product selected");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        public bool testRunning = false;
        private void autoTestToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        public bool testMode=false;
        private void enableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
           
            
            if (testMode)
            {
                testMode = false;
                autoTestToolStripMenuItem.DropDownItems[0].Text = "Enable";
                MessageBox.Show("Test Mode is now off.");
            }
            else
            {

                testMode = true;
                autoTestToolStripMenuItem.DropDownItems[0].Text = "Disable";
                MessageBox.Show("Test Mode is now on. Additional evaluation information will appear after the features selection.");
            }


        }
    }
    }

